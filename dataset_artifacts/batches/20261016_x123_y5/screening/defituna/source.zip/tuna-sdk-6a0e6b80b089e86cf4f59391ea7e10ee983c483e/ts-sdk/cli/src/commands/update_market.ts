import {
  createAddressLookupTableForMarketInstructions,
  extendAddressLookupTableForMarketInstructions,
  fetchMarket,
  getLendingVaultAddress,
  getMarketAddress,
  HUNDRED_PERCENT,
  LEVERAGE_ONE,
  MarketMaker,
  MAX_LEVERAGE,
  MAX_LIQUIDATION_FEE,
  MAX_LIQUIDATION_THRESHOLD,
  MAX_PROTOCOL_FEE,
  updateMarketInstruction,
} from "@crypticdot/defituna-client";
import { fetchFusionPool } from "@crypticdot/fusionamm-client";
import { sendTransaction } from "@crypticdot/fusionamm-tx-sender";
import { Flags } from "@oclif/core";
import { fetchWhirlpool } from "@orca-so/whirlpools-client";
import _ from "lodash";

import BaseCommand, { addressArg, addressFlag, bigintFlag, percentFlag } from "../base";
import { rpc, signer } from "../rpc";

// A devnet pool
// ORCA_POOL_USDC_DFT5 = "FKH7TTE7PgPPSb9SaaMRKVTGA7xTbiJjeTujXY2xTdxp"

// A mainnet pool
// ORCA_POOL_SOL_USDC_004 = "Czfq3xZZDmsdGdUyrNLtRhGc47cXcZtLG4crryfu44zE"

export default class UpdateMarket extends BaseCommand {
  static override args = {
    pool: addressArg({
      description: "Pool address",
      required: true,
    }),
  };
  static override flags = {
    disabled: Flags.integer({
      description: "Indicates if the market is disabled",
      min: 0,
      max: 1,
    }),
    addressLookupTable: addressFlag({
      description: "Address lookup table",
    }),
    recreateAddressLookupTable: Flags.boolean({
      description: "Creates a new address lookup table for the market",
    }),
    updateAddressLookupTable: Flags.boolean({
      description: "Updates/extends the existing address lookup table for the market",
    }),
    maxLeverage: percentFlag({
      description: "Maximum allowed leverage for the market (hundredths of a basis point or %)",
      min: LEVERAGE_ONE,
      max: MAX_LEVERAGE,
    }),
    protocolFeeOnCollateral: percentFlag({
      description: "Protocol fee on collateral (hundredths of a basis point or %)",
      min: 0,
      max: MAX_PROTOCOL_FEE,
    }),
    protocolFee: percentFlag({
      description: "Protocol fee on borrowed funds (hundredths of a basis point or %)",
      min: 0,
      max: MAX_PROTOCOL_FEE,
    }),
    liquidationFee: percentFlag({
      description: "Position liquidation fee (hundredths of a basis point or %)",
      min: 0,
      max: MAX_LIQUIDATION_FEE,
    }),
    liquidationThreshold: percentFlag({
      description: "Liquidation threshold (hundredths of a basis point or %)",
      min: 0,
      max: MAX_LIQUIDATION_THRESHOLD,
    }),
    borrowLimitA: bigintFlag({
      description: "Borrow limit A. Set to zero for unlimited borrowing",
    }),
    borrowLimitB: bigintFlag({
      description: "Borrow limit B. Set to zero for unlimited borrowing",
    }),
    spotPositionSizeLimitA: bigintFlag({
      description: "Position size limit in token A. Set to zero for unlimited size",
    }),
    spotPositionSizeLimitB: bigintFlag({
      description: "Position size limit in token B. Set to zero for unlimited size",
    }),
    oraclePriceDeviationThreshold: percentFlag({
      description: "Oracle price deviation threshold from the spot price (hundredths of a basis point or %)",
      min: 0,
      max: HUNDRED_PERCENT,
    }),
    rebalanceProtocolFee: percentFlag({
      description: "Protocol fee taken from yield on position re-balancing (hundredths of a basis point or %)",
      min: 0,
      max: HUNDRED_PERCENT / 2,
    }),
  };
  static override description = "Update a tuna market";
  static override examples = [
    "<%= config.bin %> <%= command.id %> Czfq3xZZDmsdGdUyrNLtRhGc47cXcZtLG4crryfu44zE --maxLeverage 509% --protocolFee 0.05% --liquidationFee 5% --liquidationThreshold 83%",
  ];

  public async run() {
    const { args, flags } = await this.parse(UpdateMarket);

    const marketAddress = (await getMarketAddress(args.pool))[0];
    console.log("Fetching market:", marketAddress);
    const market = await fetchMarket(rpc, marketAddress);
    console.log("Market:", market);

    const pool =
      market.data.marketMaker == MarketMaker.Fusion
        ? await fetchFusionPool(rpc, args.pool)
        : await fetchWhirlpool(rpc, args.pool);

    const isolatedVaults = market.data.vaultA != (await getLendingVaultAddress(pool.data.tokenMintA))[0];
    if (isolatedVaults) {
      if (market.data.vaultA != (await getLendingVaultAddress(pool.data.tokenMintA, marketAddress))[0]) {
        throw new Error("Unreachable code! Incorrect isolated vault address!");
      }
    }

    const newData = _.clone(market.data);

    if (flags.disabled !== undefined) {
      newData.disabled = flags.disabled != 0;
    }

    if (flags.addressLookupTable !== undefined) {
      newData.addressLookupTable = flags.addressLookupTable;
    }

    if (flags.maxLeverage !== undefined) {
      newData.maxLeverage = flags.maxLeverage;
    }

    if (flags.protocolFee !== undefined) {
      newData.protocolFee = flags.protocolFee;
    }

    if (flags.protocolFeeOnCollateral !== undefined) {
      newData.protocolFeeOnCollateral = flags.protocolFeeOnCollateral;
    }

    if (flags.liquidationFee !== undefined) {
      newData.liquidationFee = flags.liquidationFee;
    }

    if (flags.liquidationThreshold !== undefined) {
      newData.liquidationThreshold = flags.liquidationThreshold;
    }

    if (flags.borrowLimitA !== undefined) {
      newData.borrowLimitA = flags.borrowLimitA;
    }

    if (flags.borrowLimitB !== undefined) {
      newData.borrowLimitB = flags.borrowLimitB;
    }

    if (flags.spotPositionSizeLimitA !== undefined) {
      newData.spotPositionSizeLimitA = flags.spotPositionSizeLimitA;
    }

    if (flags.spotPositionSizeLimitB !== undefined) {
      newData.spotPositionSizeLimitB = flags.spotPositionSizeLimitB;
    }

    if (flags.oraclePriceDeviationThreshold !== undefined) {
      newData.oraclePriceDeviationThreshold = flags.oraclePriceDeviationThreshold;
    }

    if (flags.updateAddressLookupTable) {
      const lookupTable = await extendAddressLookupTableForMarketInstructions(
        rpc,
        args.pool,
        market.data.marketMaker,
        isolatedVaults,
        signer,
        market.data.addressLookupTable,
      );
      console.log(
        `Extending the market LUT ${newData.addressLookupTable} with ${lookupTable.addresses.length} addresses:`,
      );
      for (const address of lookupTable.addresses) {
        console.log(address);
      }

      console.log("");
      console.log("Sending a transaction...");
      const signature = await sendTransaction(rpc, lookupTable.instructions, signer);
      console.log("Transaction landed:", signature);
      return;
    }

    if (flags.recreateAddressLookupTable) {
      if (flags.addressLookupTable !== undefined) {
        throw new Error("'recreateAddressLookupTable' parameter can't be used together with 'addressLookupTable'");
      }

      const currentSlot = await rpc.getSlot({ commitment: "finalized" }).send();
      const lookupTable = await createAddressLookupTableForMarketInstructions(
        rpc,
        args.pool,
        market.data.marketMaker,
        isolatedVaults,
        signer,
        currentSlot,
      );
      newData.addressLookupTable = lookupTable.lookupTableAddress;
      console.log("Market lookup table address is:", newData.addressLookupTable);

      console.log("");
      console.log("Sending a transaction...");
      const signature = await sendTransaction(rpc, lookupTable.instructions, signer);
      console.log("Transaction landed:", signature);
    }

    const ix = await updateMarketInstruction(signer, args.pool, {
      disabled: newData.disabled,
      addressLookupTable: newData.addressLookupTable,
      maxLeverage: newData.maxLeverage,
      protocolFee: newData.protocolFee,
      protocolFeeOnCollateral: newData.protocolFeeOnCollateral,
      liquidationFee: newData.liquidationFee,
      liquidationThreshold: newData.liquidationThreshold,
      borrowLimitA: newData.borrowLimitA,
      borrowLimitB: newData.borrowLimitB,
      oraclePriceDeviationThreshold: newData.oraclePriceDeviationThreshold,
      unused: 0,
      rebalanceProtocolFee: newData.rebalanceProtocolFee,
      spotPositionSizeLimitA: newData.spotPositionSizeLimitA,
      spotPositionSizeLimitB: newData.spotPositionSizeLimitB,
    });

    console.log("");
    if (!_.isEqual(newData, market.data)) {
      console.log("Sending a transaction...");
      const signature = await sendTransaction(rpc, [ix], signer);
      console.log("Transaction landed:", signature);
    } else {
      console.log("Nothing to update!");
    }
  }
}
