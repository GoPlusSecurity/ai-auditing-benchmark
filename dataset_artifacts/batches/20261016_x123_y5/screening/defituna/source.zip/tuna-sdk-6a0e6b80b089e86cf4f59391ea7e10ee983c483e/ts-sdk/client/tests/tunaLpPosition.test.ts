import { priceToSqrtPrice, tickIndexToSqrtPrice } from "@crypticdot/fusionamm-core";
import { fetchWhirlpool, getPositionAddress } from "@orca-so/whirlpools-client";
import { generateKeyPairSigner } from "@solana/kit";
import { findAssociatedTokenPda, getTransferInstruction } from "@solana-program/token-2022";
import assert from "assert";
import { Clock } from "solana-bankrun";
import { beforeEach, describe, expect, it } from "vitest";

import {
  closeTunaLpPositionOrcaInstruction,
  COMPUTED_AMOUNT,
  DEFAULT_ADDRESS,
  fetchMarket,
  fetchTunaLpPosition,
  getResetMarketBadDebtInstruction,
  getSetTunaLpPositionFlagsInstruction,
  getTunaConfigAddress,
  getTunaLpPositionAddress,
  HUNDRED_PERCENT,
  LEVERAGE_ONE,
  MarketMaker,
  MAX_SQRT_PRICE,
  MIN_SQRT_PRICE,
  openTunaLpPositionOrcaInstruction,
  PoolToken,
  repayBadDebtInstruction,
  setTunaLpPositionLimitOrdersInstruction,
  TUNA_ERROR__BAD_DEBT,
  TUNA_ERROR__LEVERAGED_LOCKED_POSITION_NOT_ALLOWED,
  TUNA_ERROR__POSITION_IS_HEALTHY,
  TUNA_ERROR__POSITION_IS_UNHEALTHY,
  TUNA_ERROR__POSITION_LOCKED,
  TUNA_ERROR__POSITION_NOT_EMPTY,
  TUNA_ERROR__REBALANCE_CONDITIONS_NOT_MET,
  TUNA_POSITION_FLAGS_ALLOW_REBALANCING,
  TUNA_POSITION_FLAGS_LOCKED,
  TUNA_POSITION_FLAGS_LOWER_LIMIT_ORDER_SWAP_TO_TOKEN_B,
  TUNA_POSITION_FLAGS_UPPER_LIMIT_ORDER_SWAP_TO_TOKEN_A,
  TunaPositionState,
} from "../src";

import { ALICE_KEYPAIR, LIQUIDATOR_KEYPAIR, TUNA_ADMIN_KEYPAIR } from "./helpers/addresses.ts";
import { closeActiveTunaLpPosition } from "./helpers/closeActiveTunaLpPosition.ts";
import { closeTunaLpPosition } from "./helpers/closeTunaLpPosition.ts";
import { assertCollectAndCompoundFees, collectAndCompoundFees } from "./helpers/collectAndCompoundFees.ts";
import { assertCollectFees, collectFees } from "./helpers/collectFees.ts";
import { assertDecreaseTunaLpPositionLiquidity, decreaseTunaLpPosition } from "./helpers/decreaseTunaLpPosition.ts";
import { fetchPool } from "./helpers/fetch.ts";
import { assertIncreaseTunaLpPosition, increaseTunaLpPosition } from "./helpers/increaseTunaLpPosition.ts";
import { assertLiquidateTunaLpPosition, liquidateTunaLpPosition } from "./helpers/liquidateTunaLpPosition.ts";
import { getTestContext, rpc, sendTransaction, signer } from "./helpers/mockRpc.ts";
import { openAndIncreaseTunaLpPosition } from "./helpers/openAndIncreaseTunaLpPosition.ts";
import { openTunaLpPosition } from "./helpers/openTunaLpPosition.ts";
import { updateFeesAndRewards } from "./helpers/orca.ts";
import { assertRebalanceTunaLpPosition, rebalanceTunaLpPosition } from "./helpers/rebalanceTunaLpPosition.ts";
import { repayTunaLpPositionDebt } from "./helpers/repayTunaLpPositionDebt.ts";
import { setupTestMarket, TestMarket } from "./helpers/setup.ts";
import { accountExists } from "./helpers/solana.ts";
import { swapExactInput } from "./helpers/swap.ts";

describe("Tuna Liquidity Position", () => {
  let testOrcaMarket: TestMarket;
  let testFusionMarket: TestMarket;
  let testPermissionlessFusionMarket: TestMarket;
  let markets: TestMarket[];
  const marketNames = ["Orca", "Fusion", "Fusion Isolated"];

  beforeEach(async () => {
    const marketArgs = {
      addressLookupTable: DEFAULT_ADDRESS,
      borrowLimitA: 0n,
      borrowLimitB: 0n,
      disabled: false,
      liquidationFee: 10000, // 1%
      liquidationThreshold: 920000, // 92%
      maxLeverage: (LEVERAGE_ONE * 1020) / 100,
      unused: 0,
      oraclePriceDeviationThreshold: HUNDRED_PERCENT, // Allow large deviation for tests
      protocolFee: 1000, // 0.1%
      protocolFeeOnCollateral: 1000, // 0.1%
      rebalanceProtocolFee: HUNDRED_PERCENT / 10,
      spotPositionSizeLimitA: 1000_000_000_000,
      spotPositionSizeLimitB: 100000_000_000,
    };
    testOrcaMarket = await setupTestMarket({ ...marketArgs }, MarketMaker.Orca);
    testFusionMarket = await setupTestMarket({ ...marketArgs }, MarketMaker.Fusion);
    testPermissionlessFusionMarket = await setupTestMarket({ ...marketArgs }, MarketMaker.Fusion, {
      permissionless: true,
    });
    markets = [testOrcaMarket, testFusionMarket, testPermissionlessFusionMarket];
  });

  it("Open and close a position ensuring that all token accounts are closed", async () => {
    const positionMintKeypair = await generateKeyPairSigner();
    const tunaPositionAddress = (await getTunaLpPositionAddress(positionMintKeypair.address))[0];

    const tunaPositionAtaA = (
      await findAssociatedTokenPda({
        owner: tunaPositionAddress,
        mint: testOrcaMarket.mintA.address,
        tokenProgram: testOrcaMarket.mintA.programAddress,
      })
    )[0];

    const tunaPositionAtaB = (
      await findAssociatedTokenPda({
        owner: tunaPositionAddress,
        mint: testOrcaMarket.mintB.address,
        tokenProgram: testOrcaMarket.mintB.programAddress,
      })
    )[0];

    const whirlpool = await fetchWhirlpool(rpc, testOrcaMarket.pool);
    const actualTickIndex =
      whirlpool.data.tickCurrentIndex - (whirlpool.data.tickCurrentIndex % whirlpool.data.tickSpacing);

    await openTunaLpPosition({
      signer,
      positionMint: positionMintKeypair,
      pool: whirlpool.address,
      tickLowerIndex: actualTickIndex - whirlpool.data.tickSpacing,
      tickUpperIndex: actualTickIndex + whirlpool.data.tickSpacing,
    });

    expect(await accountExists(rpc, tunaPositionAddress)).toBeTruthy();
    expect(await accountExists(rpc, positionMintKeypair.address)).toBeTruthy();
    expect(await accountExists(rpc, tunaPositionAtaA)).toBeTruthy();
    expect(await accountExists(rpc, tunaPositionAtaB)).toBeTruthy();

    await sendTransaction([await closeTunaLpPositionOrcaInstruction(rpc, signer, positionMintKeypair.address)]);

    expect(await accountExists(rpc, tunaPositionAddress)).toBeFalsy();
    expect(await accountExists(rpc, positionMintKeypair.address)).toBeFalsy();
    expect(await accountExists(rpc, tunaPositionAtaA)).toBeFalsy();
    expect(await accountExists(rpc, tunaPositionAtaB)).toBeFalsy();
  });

  it("Set tuna position flags", async () => {
    const positionMintKeypair = await generateKeyPairSigner();

    const whirlpool = await fetchWhirlpool(rpc, testOrcaMarket.pool);

    const actualTickIndex =
      whirlpool.data.tickCurrentIndex - (whirlpool.data.tickCurrentIndex % whirlpool.data.tickSpacing);

    await sendTransaction([
      await openTunaLpPositionOrcaInstruction(rpc, signer, positionMintKeypair, whirlpool.address, {
        tickLowerIndex: actualTickIndex - whirlpool.data.tickSpacing,
        tickUpperIndex: actualTickIndex + whirlpool.data.tickSpacing,
        lowerLimitOrderSqrtPrice: MIN_SQRT_PRICE,
        upperLimitOrderSqrtPrice: MAX_SQRT_PRICE,
        flags: 0,
      }),
    ]);

    const tunaPositionAddress = (await getTunaLpPositionAddress(positionMintKeypair.address))[0];
    let tunaPosition = await fetchTunaLpPosition(rpc, tunaPositionAddress);
    expect(tunaPosition.data.flags).toEqual(0);

    // Set flags
    const flags = (1 << 6) - 1; // 111111
    await sendTransaction([
      getSetTunaLpPositionFlagsInstruction({ authority: signer, flags, tunaPosition: tunaPositionAddress }),
    ]);

    tunaPosition = await fetchTunaLpPosition(rpc, tunaPositionAddress);
    expect(tunaPosition.data.flags).toEqual(flags);
  });

  for (const marketName of marketNames) {
    it(`One-sided long position without swap (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const positionMintKeypair = await generateKeyPairSigner();
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      await openTunaLpPosition({
        signer,
        positionMint: positionMintKeypair,
        pool: pool.address,
        tickLowerIndex: actualTickIndex + pool.data.tickSpacing,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing * 5,
      });

      assertIncreaseTunaLpPosition(
        await increaseTunaLpPosition({
          rpc,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
          collateralA: 2_000_000_000n,
          collateralB: 0n,
          borrowA: 0n,
          borrowB: 0n,
        }),
        {
          userBalanceDeltaA: -2000000000n,
          userBalanceDeltaB: 0n,
          vaultBalanceDeltaA: 0n,
          vaultBalanceDeltaB: 0n,
          poolBalanceDeltaA: 1998000000n,
          poolBalanceDeltaB: 0n,
          leftoversA: 0n,
          leftoversB: 0n,
        },
      );

      assertDecreaseTunaLpPositionLiquidity(
        await decreaseTunaLpPosition({
          rpc,
          signer,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
          closeTunaLpPosition: true,
        }),
        {
          userBalanceDeltaA: 1997999999n,
          userBalanceDeltaB: 0n,
          vaultBalanceDeltaA: 0n,
          vaultBalanceDeltaB: 0n,
          poolBalanceDeltaA: -1997999999n,
          poolBalanceDeltaB: 0n,
        },
      );
    });
  }

  it("One-sided long position (wsol) without swap", async () => {
    // Override the test market using WSOL for MintA
    testOrcaMarket = await setupTestMarket(
      {
        addressLookupTable: DEFAULT_ADDRESS,
        borrowLimitA: 0n,
        borrowLimitB: 0n,
        disabled: false,
        liquidationFee: 10000, // 1%
        liquidationThreshold: 820000, // 82%
        maxLeverage: (LEVERAGE_ONE * 509) / 100,
        unused: 0,
        oraclePriceDeviationThreshold: HUNDRED_PERCENT / 2, // Allow large deviation for tests
        protocolFee: 1000, // 0.1%
        protocolFeeOnCollateral: 1000, // 0.1%
        rebalanceProtocolFee: HUNDRED_PERCENT / 10,
        spotPositionSizeLimitA: 1000_000_000_000,
        spotPositionSizeLimitB: 100000_000_000,
      },
      MarketMaker.Orca,
      {
        mintAIsNative: true,
      },
    );

    const positionMintKeypair = await generateKeyPairSigner();
    const whirlpool = await fetchWhirlpool(rpc, testOrcaMarket.pool);
    const actualTickIndex =
      whirlpool.data.tickCurrentIndex - (whirlpool.data.tickCurrentIndex % whirlpool.data.tickSpacing);

    await openTunaLpPosition({
      signer,
      positionMint: positionMintKeypair,
      pool: whirlpool.address,
      tickLowerIndex: actualTickIndex + whirlpool.data.tickSpacing,
      tickUpperIndex: actualTickIndex + whirlpool.data.tickSpacing * 5,
    });

    assertIncreaseTunaLpPosition(
      await increaseTunaLpPosition({
        rpc,
        positionMint: positionMintKeypair.address,
        pool: testOrcaMarket.pool,
        collateralA: 2_000_000_000n,
        collateralB: 0n,
        borrowA: 0n,
        borrowB: 0n,
      }),
      {
        userBalanceDeltaA: -2000000000n,
        userBalanceDeltaB: 0n,
        vaultBalanceDeltaA: 0n,
        vaultBalanceDeltaB: 0n,
        poolBalanceDeltaA: 1998000000n,
        poolBalanceDeltaB: 0n,
        leftoversA: 0n,
        leftoversB: 0n,
      },
    );

    assertDecreaseTunaLpPositionLiquidity(
      await decreaseTunaLpPosition({
        rpc,
        signer,
        positionMint: positionMintKeypair.address,
        pool: testOrcaMarket.pool,
        closeTunaLpPosition: true,
      }),
      {
        userBalanceDeltaA: 1997999999n,
        userBalanceDeltaB: 0n,
        vaultBalanceDeltaA: 0n,
        vaultBalanceDeltaB: 0n,
        poolBalanceDeltaA: -1997999999n,
        poolBalanceDeltaB: 0n,
      },
    );
  });

  for (const marketName of marketNames) {
    it(`One-sided short position without swap (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const positionMintKeypair = await generateKeyPairSigner();
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      await openTunaLpPosition({
        signer,
        positionMint: positionMintKeypair,
        pool: pool.address,
        tickLowerIndex: actualTickIndex - pool.data.tickSpacing * 5,
        tickUpperIndex: actualTickIndex - pool.data.tickSpacing,
      });

      assertIncreaseTunaLpPosition(
        await increaseTunaLpPosition({
          rpc,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
          collateralA: 0n,
          collateralB: 2_000_000_000n,
          borrowA: 0n,
          borrowB: 0n,
        }),
        {
          userBalanceDeltaA: 0n,
          userBalanceDeltaB: -2000000000n,
          vaultBalanceDeltaA: 0n,
          vaultBalanceDeltaB: 0n,
          poolBalanceDeltaA: 0n,
          poolBalanceDeltaB: 1998000000n,
          leftoversA: 0n,
          leftoversB: 0n,
        },
      );

      assertDecreaseTunaLpPositionLiquidity(
        await decreaseTunaLpPosition({
          rpc,
          signer,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
          closeTunaLpPosition: true,
        }),
        {
          userBalanceDeltaA: 0n,
          userBalanceDeltaB: 1997999999n,
          vaultBalanceDeltaA: 0n,
          vaultBalanceDeltaB: 0n,
          poolBalanceDeltaA: 0n,
          poolBalanceDeltaB: -1997999999n,
        },
      );
    });
  }

  for (const marketName of marketNames) {
    it(`One-sided long position without swap with leverage (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const positionMintKeypair = await generateKeyPairSigner();
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      await openTunaLpPosition({
        signer,
        positionMint: positionMintKeypair,
        pool: pool.address,
        tickLowerIndex: actualTickIndex + pool.data.tickSpacing,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing * 5,
      });

      assertIncreaseTunaLpPosition(
        await increaseTunaLpPosition({
          rpc,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
          collateralA: 1_000_000_000n,
          collateralB: 0n,
          borrowA: 1_000_000_000n,
          borrowB: 0n,
        }),
        {
          userBalanceDeltaA: -1000000000n,
          userBalanceDeltaB: 0n,
          vaultBalanceDeltaA: -1000000000n,
          vaultBalanceDeltaB: 0n,
          poolBalanceDeltaA: 1998000000n,
          poolBalanceDeltaB: 0n,
          leftoversA: 0n,
          leftoversB: 0n,
        },
      );

      assertDecreaseTunaLpPositionLiquidity(
        await decreaseTunaLpPosition({
          rpc,
          signer,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
          closeTunaLpPosition: true,
        }),
        {
          userBalanceDeltaA: 997999999n,
          userBalanceDeltaB: 0n,
          vaultBalanceDeltaA: 1000000000n,
          vaultBalanceDeltaB: 0n,
          poolBalanceDeltaA: -1997999999n,
          poolBalanceDeltaB: 0n,
        },
      );
    });
  }

  for (const marketName of marketNames) {
    it(`One-sided short position without swap with leverage (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const positionMintKeypair = await generateKeyPairSigner();
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      await openTunaLpPosition({
        signer,
        positionMint: positionMintKeypair,
        pool: pool.address,
        tickLowerIndex: actualTickIndex - pool.data.tickSpacing * 5,
        tickUpperIndex: actualTickIndex - pool.data.tickSpacing,
      });

      assertIncreaseTunaLpPosition(
        await increaseTunaLpPosition({
          rpc,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
          collateralA: 0n,
          collateralB: 1_000_000_000n,
          borrowA: 0n,
          borrowB: 1_000_000_000n,
        }),
        {
          userBalanceDeltaA: 0n,
          userBalanceDeltaB: -1000000000n,
          vaultBalanceDeltaA: 0n,
          vaultBalanceDeltaB: -1000000000n,
          poolBalanceDeltaA: 0n,
          poolBalanceDeltaB: 1998000000n,
          leftoversA: 0n,
          leftoversB: 0n,
        },
      );

      assertDecreaseTunaLpPositionLiquidity(
        await decreaseTunaLpPosition({
          rpc,
          signer,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
          closeTunaLpPosition: true,
        }),
        {
          userBalanceDeltaA: 0n,
          userBalanceDeltaB: 997999999n,
          vaultBalanceDeltaA: 0n,
          vaultBalanceDeltaB: 1000000000n,
          poolBalanceDeltaA: 0n,
          poolBalanceDeltaB: -1997999999n,
        },
      );
    });
  }

  for (const marketName of marketNames) {
    it(`One-sided long position with B->A swap with leverage (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const positionMintKeypair = await generateKeyPairSigner();
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      await openTunaLpPosition({
        signer,
        positionMint: positionMintKeypair,
        pool: pool.address,
        tickLowerIndex: actualTickIndex + pool.data.tickSpacing,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing * 5,
      });

      assertIncreaseTunaLpPosition(
        await increaseTunaLpPosition({
          rpc,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
          collateralA: 0n,
          collateralB: 1_000_000_000n,
          borrowA: 0n,
          borrowB: 1_000_000_000n,
        }),
        {
          userBalanceDeltaA: 0n,
          userBalanceDeltaB: -1000000000n,
          vaultBalanceDeltaA: 0n,
          vaultBalanceDeltaB: -1000000000n,
          poolBalanceDeltaA: 0n,
          poolBalanceDeltaB: 1998000000n,
          leftoversA: 0n,
          leftoversB: 0n,
        },
      );

      assertDecreaseTunaLpPositionLiquidity(
        await decreaseTunaLpPosition({
          rpc,
          signer,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
          closeTunaLpPosition: true,
        }),
        {
          userBalanceDeltaA: 4974415002n,
          userBalanceDeltaB: 0n,
          vaultBalanceDeltaA: 0n,
          vaultBalanceDeltaB: 1000000000n,
          poolBalanceDeltaA: -4974415002n,
          poolBalanceDeltaB: -1000000000n,
        },
      );
    });
  }

  for (const marketName of marketNames) {
    it(`One-sided short position with A->B swap with leverage (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const positionMintKeypair = await generateKeyPairSigner();
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      await openTunaLpPosition({
        signer,
        positionMint: positionMintKeypair,
        pool: pool.address,
        tickLowerIndex: actualTickIndex - pool.data.tickSpacing * 5,
        tickUpperIndex: actualTickIndex - pool.data.tickSpacing,
      });

      assertIncreaseTunaLpPosition(
        await increaseTunaLpPosition({
          rpc,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
          collateralA: 1_000_000_000n,
          collateralB: 0n,
          borrowA: 1_000_000_000n,
          borrowB: 0n,
        }),
        {
          userBalanceDeltaA: -1000000000n,
          userBalanceDeltaB: 0n,
          vaultBalanceDeltaA: -1000000000n,
          vaultBalanceDeltaB: 0n,
          poolBalanceDeltaA: 1998000000n,
          poolBalanceDeltaB: 0n,
          leftoversA: 0n,
          leftoversB: 0n,
        },
      );

      assertDecreaseTunaLpPositionLiquidity(
        await decreaseTunaLpPosition({
          rpc,
          signer,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
          closeTunaLpPosition: true,
        }),
        {
          userBalanceDeltaA: 0n,
          userBalanceDeltaB: 199331241n,
          vaultBalanceDeltaA: 1000000000n,
          vaultBalanceDeltaB: 0n,
          poolBalanceDeltaA: -1000000000n,
          poolBalanceDeltaB: -199331241n,
        },
      );
    });
  }

  for (const marketName of marketNames) {
    it(`Adds liquidity with leverage to a two-sided position, providing only token A (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const positionMintKeypair = await generateKeyPairSigner();
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      await openTunaLpPosition({
        signer,
        positionMint: positionMintKeypair,
        pool: pool.address,
        tickLowerIndex: actualTickIndex - pool.data.tickSpacing * 5,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing * 5,
      });

      assertIncreaseTunaLpPosition(
        await increaseTunaLpPosition({
          rpc,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
          collateralA: 1_000_000_000n,
          collateralB: 0n,
          borrowA: 1_000_000_000n,
          borrowB: 0n,
        }),
        {
          userBalanceDeltaA: -1000000000n,
          userBalanceDeltaB: 0n,
          vaultBalanceDeltaA: -1000000000n,
          vaultBalanceDeltaB: 0n,
          poolBalanceDeltaA: 1998000000n,
          poolBalanceDeltaB: -11n,
          leftoversA: 0n,
          leftoversB: 11n,
        },
      );

      assertDecreaseTunaLpPositionLiquidity(
        await decreaseTunaLpPosition({
          rpc,
          signer,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
          closeTunaLpPosition: true,
        }),
        {
          userBalanceDeltaA: 119946468n,
          userBalanceDeltaB: 175489131n,
          vaultBalanceDeltaA: 1000000000n,
          vaultBalanceDeltaB: 0n,
          poolBalanceDeltaA: -1119946468n,
          poolBalanceDeltaB: -175489120n,
        },
      );
    });
  }

  for (const marketName of marketNames) {
    it(`Adds liquidity with leverage to a two-sided position, providing only token B (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const positionMintKeypair = await generateKeyPairSigner();
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      await openTunaLpPosition({
        signer,
        positionMint: positionMintKeypair,
        pool: pool.address,
        tickLowerIndex: actualTickIndex - pool.data.tickSpacing * 5,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing * 5,
      });

      assertIncreaseTunaLpPosition(
        await increaseTunaLpPosition({
          rpc,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
          collateralA: 0n,
          collateralB: 1_000_000_000n,
          borrowA: 0n,
          borrowB: 1_000_000_000n,
        }),
        {
          userBalanceDeltaA: 0n,
          userBalanceDeltaB: -1000000000n,
          vaultBalanceDeltaA: 0n,
          vaultBalanceDeltaB: -1000000000n,
          poolBalanceDeltaA: -405n,
          poolBalanceDeltaB: 1998000000n,
          leftoversA: 405n,
          leftoversB: 0n,
        },
      );

      assertDecreaseTunaLpPositionLiquidity(
        await decreaseTunaLpPosition({
          rpc,
          signer,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
          closeTunaLpPosition: true,
        }),
        {
          userBalanceDeltaA: 4796455542n,
          userBalanceDeltaB: 36358256n,
          vaultBalanceDeltaA: 0n,
          vaultBalanceDeltaB: 1000000000n,
          poolBalanceDeltaA: -4796455137n,
          poolBalanceDeltaB: -1036358256n,
        },
      );
    });
  }

  for (const marketName of marketNames) {
    it(`Add liquidity twice to a one-sided long position without swap with leverage (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const positionMintKeypair = await generateKeyPairSigner();
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      await openTunaLpPosition({
        signer,
        positionMint: positionMintKeypair,
        pool: pool.address,
        tickLowerIndex: actualTickIndex + pool.data.tickSpacing,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing * 5,
      });

      for (let i = 0; i < 2; i++) {
        assertIncreaseTunaLpPosition(
          await increaseTunaLpPosition({
            rpc,
            positionMint: positionMintKeypair.address,
            pool: pool.address,
            collateralA: 1_000_000_000n,
            collateralB: 0n,
            borrowA: 1_000_000_000n,
            borrowB: 0n,
          }),
          {
            userBalanceDeltaA: -1000000000n,
            userBalanceDeltaB: 0n,
            vaultBalanceDeltaA: -1000000000n,
            vaultBalanceDeltaB: 0n,
            poolBalanceDeltaA: 1998000000n,
            poolBalanceDeltaB: 0n,
            leftoversA: 0n,
            leftoversB: 0n,
          },
        );
      }

      assertDecreaseTunaLpPositionLiquidity(
        await decreaseTunaLpPosition({
          rpc,
          signer,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
          closeTunaLpPosition: true,
        }),
        {
          userBalanceDeltaA: 1995999999n,
          userBalanceDeltaB: 0n,
          vaultBalanceDeltaA: 2000000000n,
          vaultBalanceDeltaB: 0n,
          poolBalanceDeltaA: -3995999999n,
          poolBalanceDeltaB: 0n,
        },
      );
    });
  }

  for (const marketName of marketNames) {
    it(`Remove liquidity partially form a one-sided long position with leverage (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const positionMintKeypair = await generateKeyPairSigner();
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      await openTunaLpPosition({
        signer,
        positionMint: positionMintKeypair,
        pool: pool.address,
        tickLowerIndex: actualTickIndex + pool.data.tickSpacing,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing * 5,
      });

      assertIncreaseTunaLpPosition(
        await increaseTunaLpPosition({
          rpc,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
          collateralA: 2_000_000_000n,
          collateralB: 0n,
          borrowA: 2_000_000_000n,
          borrowB: 0n,
        }),
        {
          userBalanceDeltaA: -2000000000n,
          userBalanceDeltaB: 0n,
          vaultBalanceDeltaA: -2000000000n,
          vaultBalanceDeltaB: 0n,
          poolBalanceDeltaA: 3996000000n,
          poolBalanceDeltaB: 0n,
          leftoversA: 0n,
          leftoversB: 0n,
        },
      );

      assertDecreaseTunaLpPositionLiquidity(
        await decreaseTunaLpPosition({
          rpc,
          signer,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
          decreasePercent: HUNDRED_PERCENT / 2,
        }),
        {
          userBalanceDeltaA: 997999999n,
          userBalanceDeltaB: 0n,
          vaultBalanceDeltaA: 1000000000n,
          vaultBalanceDeltaB: 0n,
          poolBalanceDeltaA: -1997999999n,
          poolBalanceDeltaB: 0n,
        },
      );

      assertDecreaseTunaLpPositionLiquidity(
        await decreaseTunaLpPosition({
          rpc,
          signer,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
          decreasePercent: HUNDRED_PERCENT,
          closeTunaLpPosition: true,
        }),
        {
          userBalanceDeltaA: 998000000n,
          userBalanceDeltaB: 0n,
          vaultBalanceDeltaA: 1000000000n,
          vaultBalanceDeltaB: 0n,
          poolBalanceDeltaA: -1998000000n,
          poolBalanceDeltaB: 0n,
        },
      );
    });
  }

  for (const marketName of marketNames) {
    it(`Fails to remove more than 100% of liquidity (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const positionMintKeypair = await generateKeyPairSigner();
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      await openTunaLpPosition({
        signer,
        positionMint: positionMintKeypair,
        pool: pool.address,
        tickLowerIndex: actualTickIndex + pool.data.tickSpacing,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing * 5,
      });

      await increaseTunaLpPosition({
        rpc,
        positionMint: positionMintKeypair.address,
        pool: pool.address,
        collateralA: 2_000_000_000n,
        collateralB: 0n,
        borrowA: 2_000_000_000n,
        borrowB: 0n,
      });

      await assert.rejects(
        decreaseTunaLpPosition({
          rpc,
          signer,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
          decreasePercent: HUNDRED_PERCENT + 1,
          closeTunaLpPosition: true,
        }),
      );
    });
  }

  for (const marketName of marketNames) {
    it(`Two-sided position with leverage and disabled swap: A provided, B calculated (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const positionMintKeypair = await generateKeyPairSigner();
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      await openTunaLpPosition({
        signer,
        positionMint: positionMintKeypair,
        pool: pool.address,
        tickLowerIndex: actualTickIndex - pool.data.tickSpacing * 5,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing * 5,
      });

      assertIncreaseTunaLpPosition(
        await increaseTunaLpPosition({
          rpc,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
          collateralA: 1_000_000_000n,
          collateralB: COMPUTED_AMOUNT,
          borrowA: 1_000_000_000n,
          borrowB: COMPUTED_AMOUNT,
        }),
        {
          userBalanceDeltaA: -1000000000n,
          userBalanceDeltaB: -164737435n,
          vaultBalanceDeltaA: -1000000000n,
          vaultBalanceDeltaB: -164737435n,
          poolBalanceDeltaA: 1998000000n,
          poolBalanceDeltaB: 329145395n,
          leftoversA: 0n,
          leftoversB: 1n,
        },
      );

      await decreaseTunaLpPosition({
        rpc,
        signer,
        positionMint: positionMintKeypair.address,
        pool: pool.address,
        closeTunaLpPosition: true,
      });
    });
  }

  for (const marketName of marketNames) {
    it(`Two-sided position with leverage and disabled swap: B provided, A calculated (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const positionMintKeypair = await generateKeyPairSigner();
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      await openTunaLpPosition({
        signer,
        positionMint: positionMintKeypair,
        pool: pool.address,
        tickLowerIndex: actualTickIndex - pool.data.tickSpacing * 5,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing * 5,
      });

      assertIncreaseTunaLpPosition(
        await increaseTunaLpPosition({
          rpc,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
          collateralA: COMPUTED_AMOUNT,
          collateralB: 1_000_000_000n,
          borrowA: COMPUTED_AMOUNT,
          borrowB: 1_000_000_000n,
        }),
        {
          userBalanceDeltaA: -6070265710n,
          userBalanceDeltaB: -1000000000n,
          vaultBalanceDeltaA: -6070265710n,
          vaultBalanceDeltaB: -1000000000n,
          poolBalanceDeltaA: 12128390889n,
          poolBalanceDeltaB: 1998000000n,
          leftoversA: 0n,
          leftoversB: 0n,
        },
      );

      await decreaseTunaLpPosition({
        rpc,
        signer,
        positionMint: positionMintKeypair.address,
        pool: pool.address,
        closeTunaLpPosition: true,
      });
    });
  }

  for (const marketName of marketNames) {
    it(`One-sided long position with leverage and disabled swap (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const positionMintKeypair = await generateKeyPairSigner();
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      await openTunaLpPosition({
        signer,
        positionMint: positionMintKeypair,
        pool: pool.address,
        tickLowerIndex: actualTickIndex + pool.data.tickSpacing,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing * 5,
      });

      // Fails to add liquidity with incorrect arguments
      await assert.rejects(
        increaseTunaLpPosition({
          rpc,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
          collateralA: COMPUTED_AMOUNT,
          collateralB: 1_000_000_000n,
          borrowA: COMPUTED_AMOUNT,
          borrowB: 1_000_000_000n,
        }),
      );

      assertIncreaseTunaLpPosition(
        await increaseTunaLpPosition({
          rpc,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
          collateralA: 1_000_000_000n,
          collateralB: COMPUTED_AMOUNT,
          borrowA: 1_000_000_000n,
          borrowB: COMPUTED_AMOUNT,
        }),
        {
          userBalanceDeltaA: -1000000000n,
          userBalanceDeltaB: 0n,
          vaultBalanceDeltaA: -1000000000n,
          vaultBalanceDeltaB: 0n,
          poolBalanceDeltaA: 1998000000n,
          poolBalanceDeltaB: 0n,
          leftoversA: 0n,
          leftoversB: 0n,
        },
      );

      await decreaseTunaLpPosition({
        rpc,
        signer,
        positionMint: positionMintKeypair.address,
        pool: pool.address,
        closeTunaLpPosition: true,
      });
    });
  }

  for (const marketName of marketNames) {
    it(`One-sided short position with leverage and disabled swap (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const positionMintKeypair = await generateKeyPairSigner();
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      await openTunaLpPosition({
        signer,
        positionMint: positionMintKeypair,
        pool: pool.address,
        tickLowerIndex: actualTickIndex - pool.data.tickSpacing * 5,
        tickUpperIndex: actualTickIndex - pool.data.tickSpacing,
      });

      // Fails to add liquidity with incorrect arguments
      await assert.rejects(
        increaseTunaLpPosition({
          rpc,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
          collateralA: 1_000_000_000n,
          collateralB: COMPUTED_AMOUNT,
          borrowA: 1_000_000_000n,
          borrowB: COMPUTED_AMOUNT,
        }),
      );

      assertIncreaseTunaLpPosition(
        await increaseTunaLpPosition({
          rpc,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
          collateralA: COMPUTED_AMOUNT,
          collateralB: 1_000_000_000n,
          borrowA: COMPUTED_AMOUNT,
          borrowB: 1_000_000_000n,
        }),
        {
          userBalanceDeltaA: 0n,
          userBalanceDeltaB: -1000000000n,
          vaultBalanceDeltaA: 0n,
          vaultBalanceDeltaB: -1000000000n,
          poolBalanceDeltaA: 0n,
          poolBalanceDeltaB: 1998000000n,
          leftoversA: 0n,
          leftoversB: 0n,
        },
      );

      await decreaseTunaLpPosition({
        rpc,
        signer,
        positionMint: positionMintKeypair.address,
        pool: pool.address,
        closeTunaLpPosition: true,
      });
    });
  }

  for (const marketName of marketNames) {
    it(`Collect position fees (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const positionMintKeypair = await generateKeyPairSigner();
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      await openTunaLpPosition({
        signer,
        positionMint: positionMintKeypair,
        pool: pool.address,
        tickLowerIndex: actualTickIndex - pool.data.tickSpacing * 20,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing * 20,
      });

      await increaseTunaLpPosition({
        rpc,
        positionMint: positionMintKeypair.address,
        pool: pool.address,
        collateralA: 2_000_000_000n,
        collateralB: 0n,
        borrowA: 2_000_000_000n,
        borrowB: 0n,
      });

      await swapExactInput(rpc, signer, pool.address, 1_000_000_000n, market.mintA.address);

      assertCollectFees(
        await collectFees({
          rpc,
          signer,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
        }),
        {
          userBalanceDeltaA: 4217n,
          userBalanceDeltaB: 0n,
          poolBalanceDeltaA: -4217n,
          poolBalanceDeltaB: 0n,
        },
      );

      await swapExactInput(rpc, signer, pool.address, 1_000_000_000n, market.mintB.address);

      assertCollectFees(
        await collectFees({
          rpc,
          signer,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
        }),
        {
          userBalanceDeltaA: 0n,
          userBalanceDeltaB: 4217n,
          poolBalanceDeltaA: 0n,
          poolBalanceDeltaB: -4217n,
        },
      );

      // Nothing to collect
      assertCollectFees(
        await collectFees({
          rpc,
          signer,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
        }),
        {
          userBalanceDeltaA: 0n,
          userBalanceDeltaB: 0n,
          poolBalanceDeltaA: 0n,
          poolBalanceDeltaB: 0n,
        },
      );

      await decreaseTunaLpPosition({
        rpc,
        signer,
        positionMint: positionMintKeypair.address,
        pool: pool.address,
        decreasePercent: HUNDRED_PERCENT,
        closeTunaLpPosition: true,
      });
    });
  }

  for (const marketName of marketNames) {
    it(`Fails to increase, decrease, collect fees and close a position with non-authority wallet (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const positionMintKeypair = await generateKeyPairSigner();
      const positionMint = positionMintKeypair.address;
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      await openTunaLpPosition({
        signer,
        positionMint: positionMintKeypair,
        pool: pool.address,
        tickLowerIndex: actualTickIndex + pool.data.tickSpacing,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing * 5,
      });

      await increaseTunaLpPosition({
        rpc,
        positionMint,
        pool: pool.address,
        collateralA: 2_000_000_000n,
        collateralB: 0n,
        borrowA: 2_000_000_000n,
        borrowB: 0n,
      });

      await assert.rejects(
        increaseTunaLpPosition({
          rpc,
          signer: ALICE_KEYPAIR,
          positionMint,
          pool: pool.address,
          collateralA: 2_000_000_000n,
          collateralB: 0n,
          borrowA: 2_000_000_000n,
          borrowB: 0n,
        }),
      );

      await swapExactInput(rpc, signer, pool.address, 100_000_000n, market.mintA.address);

      await assert.rejects(
        collectFees({
          rpc,
          signer: ALICE_KEYPAIR,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
        }),
      );

      await collectFees({
        rpc,
        signer,
        positionMint: positionMintKeypair.address,
        pool: pool.address,
      });

      await assert.rejects(
        decreaseTunaLpPosition({
          rpc,
          signer: ALICE_KEYPAIR,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
          decreasePercent: HUNDRED_PERCENT,
        }),
      );

      await decreaseTunaLpPosition({
        rpc,
        signer,
        positionMint: positionMintKeypair.address,
        pool: pool.address,
        decreasePercent: HUNDRED_PERCENT,
      });

      await assert.rejects(closeTunaLpPosition({ rpc, signer: ALICE_KEYPAIR, positionMint }));
      await closeTunaLpPosition({ rpc, signer, positionMint });
    });
  }

  it("Fails to add liquidity because of the borrow limit", async () => {
    // Override the test market with opened interest
    testOrcaMarket = await setupTestMarket(
      {
        addressLookupTable: DEFAULT_ADDRESS,
        borrowLimitA: 2_000_000_000n,
        borrowLimitB: 0n,
        disabled: false,
        liquidationFee: 10000, // 1%
        liquidationThreshold: 820000, // 82%
        maxLeverage: (LEVERAGE_ONE * 509) / 100,
        unused: 0,
        oraclePriceDeviationThreshold: HUNDRED_PERCENT / 2, // Allow large deviation for tests
        protocolFee: 1000, // 0.1%
        protocolFeeOnCollateral: 1000, // 0.1%
        rebalanceProtocolFee: HUNDRED_PERCENT / 10,
        spotPositionSizeLimitA: 1000_000_000_000,
        spotPositionSizeLimitB: 100000_000_000,
      },
      MarketMaker.Orca,
    );

    const positionMintKeypair = await generateKeyPairSigner();
    const whirlpool = await fetchWhirlpool(rpc, testOrcaMarket.pool);
    const actualTickIndex =
      whirlpool.data.tickCurrentIndex - (whirlpool.data.tickCurrentIndex % whirlpool.data.tickSpacing);

    await openTunaLpPosition({
      signer,
      positionMint: positionMintKeypair,
      pool: whirlpool.address,
      tickLowerIndex: actualTickIndex + whirlpool.data.tickSpacing,
      tickUpperIndex: actualTickIndex + whirlpool.data.tickSpacing * 5,
    });

    // Borrow less than the limit
    await increaseTunaLpPosition({
      rpc,
      signer,
      positionMint: positionMintKeypair.address,
      pool: testOrcaMarket.pool,
      collateralA: 1_000_000_000n,
      collateralB: 0n,
      borrowA: 1_000_000_000n,
      borrowB: 0n,
    });

    await assert.rejects(
      increaseTunaLpPosition({
        rpc,
        signer,
        positionMint: positionMintKeypair.address,
        pool: testOrcaMarket.pool,
        collateralA: 1_000_000_000n,
        collateralB: 0n,
        borrowA: 1_000_000_001n, // Borrow more than allowed
        borrowB: 0n,
      }),
    );
  });

  for (const marketName of marketNames) {
    it(`Fails to borrow more from due to leverage greater than the maximum allowed (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const positionMintKeypair = await generateKeyPairSigner();
      const positionMint = positionMintKeypair.address;
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      await openTunaLpPosition({
        signer,
        positionMint: positionMintKeypair,
        pool: pool.address,
        tickLowerIndex: actualTickIndex + pool.data.tickSpacing,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing * 5,
      });

      // Borrow less than the limit
      await increaseTunaLpPosition({
        rpc,
        signer,
        positionMint,
        pool: pool.address,
        collateralA: 1_000_000_000n,
        collateralB: 0n,
        borrowA: 1_000_000_000n,
        borrowB: 0n,
      });

      await assert.rejects(
        increaseTunaLpPosition({
          rpc,
          signer,
          positionMint,
          pool: pool.address,
          collateralA: 100_000_000n,
          collateralB: 0n,
          borrowA: 10_000_000_000n, // Borrow more than allowed
          borrowB: 0n,
        }),
      );
    });
  }

  for (const marketName of marketNames) {
    it(`Fails to liquidate the position due to: a) unauthorized b) position being healthy (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const positionMintKeypair = await generateKeyPairSigner();
      const positionMint = positionMintKeypair.address;
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      await openTunaLpPosition({
        signer,
        positionMint: positionMintKeypair,
        pool: pool.address,
        tickLowerIndex: actualTickIndex + pool.data.tickSpacing,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing * 5,
      });

      await increaseTunaLpPosition({
        rpc,
        signer,
        positionMint,
        pool: pool.address,
        collateralA: 1_000_000_000n,
        collateralB: 0n,
        borrowA: 1_000_000_000n,
        borrowB: 0n,
      });

      await assert.rejects(liquidateTunaLpPosition({ rpc, signer, positionMint }), err => {
        // AnchorError caused by account: authority. Error Code: ConstraintRaw. Error Number: 2003. Error Message: A raw constraint was violated.
        expect((err as Error).toString()).contain("custom program error: 0x7dc");
        return true;
      });

      await assert.rejects(liquidateTunaLpPosition({ rpc, signer: LIQUIDATOR_KEYPAIR, positionMint }), err => {
        expect((err as Error).toString()).contain(
          `custom program error: ${"0x" + TUNA_ERROR__POSITION_IS_HEALTHY.toString(16)}`,
        );
        return true;
      });
    });
  }

  for (const marketName of marketNames) {
    it(`Liquidates a position due to an unhealthy state (no bad debt) (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      const positionMint = await openAndIncreaseTunaLpPosition({
        rpc,
        tickLowerIndex: actualTickIndex - pool.data.tickSpacing * 3,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing * 3,
        pool: pool.address,
        collateralA: 1_000_000_000n,
        collateralB: 0n,
        borrowA: 4_000_000_000n,
        borrowB: 0n,
      });

      //const whirlpoolBefore = await fetchWhirlpool(rpc, testMarket.pool);

      // Significantly move the price.
      await swapExactInput(rpc, signer, pool.address, 50_000_000_000n, market.mintB.address);

      //const whirlpoolAfter = await fetchWhirlpool(rpc, testMarket.pool);
      //console.log(
      //  `Price moved from ${sqrtPriceToPrice(whirlpoolBefore.data.sqrtPrice, 9, 6)} to ${sqrtPriceToPrice(whirlpoolAfter.data.sqrtPrice, 9, 6)}`,
      //);

      assertLiquidateTunaLpPosition(await liquidateTunaLpPosition({ rpc, signer: LIQUIDATOR_KEYPAIR, positionMint }), {
        vaultBalanceDeltaA: 4000000000n,
        vaultBalanceDeltaB: 0n,
        poolBalanceDeltaA: -4000000000n,
        poolBalanceDeltaB: -18144803n,
        badDebtDeltaA: 0n,
        badDebtDeltaB: 0n,
        tunaPositionState: TunaPositionState.Liquidated,
      });

      // Fails to close the position because it's not empty.
      await assert.rejects(closeTunaLpPosition({ rpc, signer, positionMint }), err => {
        expect((err as Error).toString()).contain(
          `custom program error: ${"0x" + TUNA_ERROR__POSITION_NOT_EMPTY.toString(16)}`,
        );
        return true;
      });

      assertDecreaseTunaLpPositionLiquidity(
        await decreaseTunaLpPosition({
          rpc,
          signer,
          positionMint,
          pool: pool.address,
          decreasePercent: HUNDRED_PERCENT,
        }),
        {
          userBalanceDeltaA: 0n,
          userBalanceDeltaB: 8092506n,
          vaultBalanceDeltaA: 0n,
          vaultBalanceDeltaB: 0n,
          poolBalanceDeltaA: 0n,
          poolBalanceDeltaB: 0n,
        },
      );
    });
  }

  for (const marketName of marketNames) {
    it(`Liquidates a position with directly transferred tokens (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      const positionMint = await openAndIncreaseTunaLpPosition({
        rpc,
        tickLowerIndex: actualTickIndex - pool.data.tickSpacing * 3,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing * 3,
        pool: pool.address,
        collateralA: 1_000_000_000n,
        collateralB: 0n,
        borrowA: 4_000_000_000n,
        borrowB: 0n,
      });

      const tunaPositionAddress = (await getTunaLpPositionAddress(positionMint))[0];

      const signerAtaA = (
        await findAssociatedTokenPda({
          mint: market.mintA.address,
          owner: signer.address,
          tokenProgram: market.mintA.programAddress,
        })
      )[0];

      const signerAtaB = (
        await findAssociatedTokenPda({
          mint: market.mintB.address,
          owner: signer.address,
          tokenProgram: market.mintB.programAddress,
        })
      )[0];

      const tunaPositionAtaA = (
        await findAssociatedTokenPda({
          owner: tunaPositionAddress,
          mint: market.mintA.address,
          tokenProgram: market.mintA.programAddress,
        })
      )[0];

      const tunaPositionAtaB = (
        await findAssociatedTokenPda({
          owner: tunaPositionAddress,
          mint: market.mintB.address,
          tokenProgram: market.mintB.programAddress,
        })
      )[0];

      const transferTokensToThePosition = async () => {
        await sendTransaction([
          getTransferInstruction(
            {
              authority: signer,
              source: signerAtaA,
              destination: tunaPositionAtaA,
              amount: 1_000_000_000n,
            },
            { programAddress: market.mintA.programAddress },
          ),
          getTransferInstruction(
            {
              authority: signer,
              source: signerAtaB,
              destination: tunaPositionAtaB,
              amount: 400_000_000n,
            },
            { programAddress: market.mintB.programAddress },
          ),
        ]);
      };

      // Significantly move the price.
      await swapExactInput(rpc, signer, pool.address, 50_000_000_000n, market.mintB.address);

      await transferTokensToThePosition();

      assertLiquidateTunaLpPosition(await liquidateTunaLpPosition({ rpc, signer: LIQUIDATOR_KEYPAIR, positionMint }), {
        vaultBalanceDeltaA: 4000000000n,
        vaultBalanceDeltaB: 0n,
        poolBalanceDeltaA: -4000000000n,
        poolBalanceDeltaB: -18144803n,
        badDebtDeltaA: 0n,
        badDebtDeltaB: 0n,
        tunaPositionState: TunaPositionState.Liquidated,
      });

      assertDecreaseTunaLpPositionLiquidity(
        await decreaseTunaLpPosition({
          rpc,
          signer,
          positionMint,
          pool: pool.address,
          decreasePercent: HUNDRED_PERCENT,
        }),
        {
          userBalanceDeltaA: 0n,
          userBalanceDeltaB: 8092506n,
          vaultBalanceDeltaA: 0n,
          vaultBalanceDeltaB: 0n,
          poolBalanceDeltaA: 0n,
          poolBalanceDeltaB: 0n,
        },
      );
    });
  }

  for (const marketName of marketNames) {
    it(`Liquidates a position due to an unhealthy state (bad debt A) (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const positionMintKeypair = await generateKeyPairSigner();
      const positionMint = positionMintKeypair.address;
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);
      const tunaConfigAddress = (await getTunaConfigAddress())[0];

      await openTunaLpPosition({
        signer,
        positionMint: positionMintKeypair,
        pool: pool.address,
        tickLowerIndex: actualTickIndex - pool.data.tickSpacing * 3,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing * 3,
      });

      await increaseTunaLpPosition({
        rpc,
        signer,
        positionMint,
        pool: pool.address,
        collateralA: 1_000_000_000n,
        collateralB: 0n,
        borrowA: 9_000_000_000n,
        borrowB: 0n,
      });

      //const whirlpoolBefore = await fetchWhirlpool(rpc, testMarket.pool);

      // Significantly move the price.
      await swapExactInput(rpc, signer, pool.address, 50_000_000_000n, pool.data.tokenMintB);

      //const whirlpoolAfter = await fetchWhirlpool(rpc, testMarket.pool);
      //console.log(
      //`Price moved from ${sqrtPriceToPrice(whirlpoolBefore.data.sqrtPrice, 9, 6)} to ${sqrtPriceToPrice(whirlpoolAfter.data.sqrtPrice, 9, 6)}`,
      //);

      assertLiquidateTunaLpPosition(await liquidateTunaLpPosition({ rpc, signer: LIQUIDATOR_KEYPAIR, positionMint }), {
        vaultBalanceDeltaA: 8161132905n,
        vaultBalanceDeltaB: 0n,
        poolBalanceDeltaA: -8161132905n,
        poolBalanceDeltaB: 31n,
        badDebtDeltaA: 838867095n,
        badDebtDeltaB: 0n,
        tunaPositionState: TunaPositionState.Liquidated,
      });

      assertDecreaseTunaLpPositionLiquidity(
        await decreaseTunaLpPosition({
          rpc,
          signer,
          positionMint,
          pool: pool.address,
          decreasePercent: HUNDRED_PERCENT,
        }),
        {
          userBalanceDeltaA: 0n,
          userBalanceDeltaB: 0n,
          vaultBalanceDeltaA: 0n,
          vaultBalanceDeltaB: 0n,
          poolBalanceDeltaA: 0n,
          poolBalanceDeltaB: 0n,
        },
      );

      // Market bad debt reset fails because the bad debt is not repaid
      await assert.rejects(
        sendTransaction([
          getResetMarketBadDebtInstruction({
            authority: TUNA_ADMIN_KEYPAIR,
            market: market.marketAddress,
            tunaConfig: tunaConfigAddress,
            vaultA: market.vaultAAddress,
            vaultB: market.vaultBAddress,
          }),
        ]),
        err => {
          expect((err as Error).toString()).contain(
            `custom program error: ${"0x" + TUNA_ERROR__BAD_DEBT.toString(16)}`,
          );
          return true;
        },
      );

      await sendTransaction([await repayBadDebtInstruction(rpc, signer, market.vaultAAddress, 0n, 838867095n)]);

      await sendTransaction([
        getResetMarketBadDebtInstruction({
          authority: TUNA_ADMIN_KEYPAIR,
          market: market.marketAddress,
          tunaConfig: tunaConfigAddress,
          vaultA: market.vaultAAddress,
          vaultB: market.vaultBAddress,
        }),
      ]);

      const marketAccount = await fetchMarket(rpc, market.marketAddress);
      expect(marketAccount.data.badDebtA).toEqual(0n);
      expect(marketAccount.data.badDebtB).toEqual(0n);
      expect(marketAccount.data.borrowedSharesA).toEqual(0n);
      expect(marketAccount.data.borrowedSharesB).toEqual(0n);
    });
  }

  for (const marketName of marketNames) {
    it(`Liquidates a position due to an unhealthy state (bad debt B) (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const positionMintKeypair = await generateKeyPairSigner();
      const positionMint = positionMintKeypair.address;
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      await openTunaLpPosition({
        signer,
        positionMint: positionMintKeypair,
        pool: pool.address,
        tickLowerIndex: actualTickIndex - pool.data.tickSpacing * 3,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing * 3,
      });

      await increaseTunaLpPosition({
        rpc,
        signer,
        positionMint,
        pool: pool.address,
        collateralA: 0n,
        collateralB: 1_000_000n,
        borrowA: 0n,
        borrowB: 9_000_000n,
      });

      //const whirlpoolBefore = await fetchWhirlpool(rpc, testMarket.pool);

      // Significantly move the price.
      await swapExactInput(rpc, signer, pool.address, 1000_000_000_000n, pool.data.tokenMintA);

      //const whirlpoolAfter = await fetchWhirlpool(rpc, testMarket.pool);
      //console.log(
      //  `Price moved from ${sqrtPriceToPrice(whirlpoolBefore.data.sqrtPrice, 9, 6)} to ${sqrtPriceToPrice(whirlpoolAfter.data.sqrtPrice, 9, 6)}`,
      //);

      assertLiquidateTunaLpPosition(await liquidateTunaLpPosition({ rpc, signer: LIQUIDATOR_KEYPAIR, positionMint }), {
        vaultBalanceDeltaA: 0n,
        vaultBalanceDeltaB: 4785196n,
        poolBalanceDeltaA: 6n,
        poolBalanceDeltaB: -4785196n,
        badDebtDeltaA: 0n,
        badDebtDeltaB: 4214804n,
        tunaPositionState: TunaPositionState.Liquidated,
      });

      assertDecreaseTunaLpPositionLiquidity(
        await decreaseTunaLpPosition({
          rpc,
          signer,
          positionMint,
          pool: pool.address,
          decreasePercent: HUNDRED_PERCENT,
        }),
        {
          userBalanceDeltaA: 0n,
          userBalanceDeltaB: 0n,
          vaultBalanceDeltaA: 0n,
          vaultBalanceDeltaB: 0n,
          poolBalanceDeltaA: 0n,
          poolBalanceDeltaB: 0n,
        },
      );
    });
  }

  for (const marketName of marketNames) {
    it(`Fails to remove liquidity from an unhealthy position (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      const positionMint = await openAndIncreaseTunaLpPosition({
        rpc,
        tickLowerIndex: actualTickIndex - pool.data.tickSpacing * 3,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing * 3,
        pool: pool.address,
        collateralA: 1_000_000_000n,
        collateralB: 0n,
        borrowA: 4_000_000_000n,
        borrowB: 0n,
      });

      // Significantly move the price.
      await swapExactInput(rpc, signer, pool.address, 50_000_000_000n, pool.data.tokenMintB);

      // Fails to partially remove liquidity from an unhealthy position
      await assert.rejects(
        decreaseTunaLpPosition({
          rpc,
          signer,
          positionMint,
          pool: pool.address,
          decreasePercent: HUNDRED_PERCENT / 100,
        }),
        err => {
          expect((err as Error).toString()).contain(
            `custom program error: ${"0x" + TUNA_ERROR__POSITION_IS_UNHEALTHY.toString(16)}`,
          );
          return true;
        },
      );

      // Fails to totally remove liquidity from an unhealthy position
      await assert.rejects(
        decreaseTunaLpPosition({
          rpc,
          signer,
          positionMint,
          pool: pool.address,
          decreasePercent: HUNDRED_PERCENT,
        }),
        err => {
          expect((err as Error).toString()).contain(
            `custom program error: ${"0x" + TUNA_ERROR__POSITION_IS_UNHEALTHY.toString(16)}`,
          );
          return true;
        },
      );
    });
  }

  for (const marketName of marketNames) {
    it(`Can execute openAndIncreaseTunaLpPosition instruction (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      await openAndIncreaseTunaLpPosition({
        rpc,
        tickLowerIndex: actualTickIndex + pool.data.tickSpacing,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing * 5,
        pool: pool.address,
        collateralA: 2_000_000_000n,
        collateralB: 0n,
        borrowA: 2_000_000_000n,
        borrowB: 0n,
      });
    });
  }

  for (const marketName of marketNames) {
    it(`Adds liquidity to a two-sided position and withdraw the entire amount in token A (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      const positionMint = await openAndIncreaseTunaLpPosition({
        rpc,
        tickLowerIndex: actualTickIndex - pool.data.tickSpacing * 5,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing * 5,
        pool: pool.address,
        collateralA: 1_000_000_000n,
        collateralB: 100_000_000n,
        borrowA: 2_000_000_000n,
        borrowB: 200_000_000n,
      });

      assertDecreaseTunaLpPositionLiquidity(
        await decreaseTunaLpPosition({
          rpc,
          signer,
          positionMint,
          pool: pool.address,
          swapToToken: PoolToken.A,
          closeTunaLpPosition: true,
        }),
        {
          userBalanceDeltaA: 1494939298n,
          userBalanceDeltaB: 0n,
          vaultBalanceDeltaA: 2_000_000_000n,
          vaultBalanceDeltaB: 200_000_000n,
          poolBalanceDeltaA: -3494939298n,
          poolBalanceDeltaB: -199999994n,
        },
      );
    });
  }

  for (const marketName of marketNames) {
    it(`Adds liquidity to a two-sided position and withdraw the entire amount in token B (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      const positionMint = await openAndIncreaseTunaLpPosition({
        rpc,
        tickLowerIndex: actualTickIndex - pool.data.tickSpacing * 5,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing * 5,
        pool: pool.address,
        collateralA: 1_000_000_000n,
        collateralB: 100_000_000n,
        borrowA: 2_000_000_000n,
        borrowB: 200_000_000n,
      });

      assertDecreaseTunaLpPositionLiquidity(
        await decreaseTunaLpPosition({
          rpc,
          signer,
          positionMint,
          pool: pool.address,
          swapToToken: PoolToken.B,
          closeTunaLpPosition: true,
        }),
        {
          userBalanceDeltaA: 0n,
          userBalanceDeltaB: 298951363n,
          vaultBalanceDeltaA: 2_000_000_000n,
          vaultBalanceDeltaB: 200_000_000n,
          poolBalanceDeltaA: -2000000000n,
          poolBalanceDeltaB: -498951357n,
        },
      );
    });
  }

  for (const marketName of marketNames) {
    it(`S/L limit order (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      const positionMint = await openAndIncreaseTunaLpPosition({
        rpc,
        tickLowerIndex: actualTickIndex - pool.data.tickSpacing,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing,
        lowerLimitOrderSqrtPrice: tickIndexToSqrtPrice(actualTickIndex - pool.data.tickSpacing * 2),
        pool: pool.address,
        collateralA: 1_000_000_000n,
        collateralB: 100_000_000n,
        borrowA: 2_000_000_000n,
        borrowB: 200_000_000n,
      });

      // Move the price.
      await swapExactInput(rpc, signer, pool.address, 100_000_000_000n, pool.data.tokenMintA);

      assertLiquidateTunaLpPosition(await liquidateTunaLpPosition({ rpc, signer: LIQUIDATOR_KEYPAIR, positionMint }), {
        tunaPositionState: TunaPositionState.ClosedByLimitOrder,
        feeRecipientBalanceDeltaA: 4497643n,
        feeRecipientBalanceDeltaB: 0n,
      });
    });
  }

  for (const marketName of marketNames) {
    it(`S/L limit order, swap to token B (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      const positionMint = await openAndIncreaseTunaLpPosition({
        rpc,
        tickLowerIndex: actualTickIndex - pool.data.tickSpacing,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing,
        lowerLimitOrderSqrtPrice: tickIndexToSqrtPrice(actualTickIndex - pool.data.tickSpacing * 2),
        pool: pool.address,
        collateralA: 1_000_000_000n,
        collateralB: 100_000_000n,
        borrowA: 2_000_000_000n,
        borrowB: 200_000_000n,
        flags: TUNA_POSITION_FLAGS_LOWER_LIMIT_ORDER_SWAP_TO_TOKEN_B,
      });

      // Move the price.
      await swapExactInput(rpc, signer, pool.address, 100_000_000_000n, pool.data.tokenMintA);

      assertLiquidateTunaLpPosition(await liquidateTunaLpPosition({ rpc, signer: LIQUIDATOR_KEYPAIR, positionMint }), {
        tunaPositionState: TunaPositionState.ClosedByLimitOrder,
        feeRecipientBalanceDeltaA: 4497643n,
        feeRecipientBalanceDeltaB: 0n,
      });
    });
  }

  for (const marketName of marketNames) {
    it(`T/P limit order (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      const positionMint = await openAndIncreaseTunaLpPosition({
        rpc,
        tickLowerIndex: actualTickIndex - pool.data.tickSpacing,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing,
        upperLimitOrderSqrtPrice: tickIndexToSqrtPrice(actualTickIndex + pool.data.tickSpacing * 2),
        pool: pool.address,
        collateralA: 1_000_000_000n,
        collateralB: 100_000_000n,
        borrowA: 2_000_000_000n,
        borrowB: 200_000_000n,
      });

      // Move the price.
      await swapExactInput(rpc, signer, pool.address, 10_000_000_000n, pool.data.tokenMintB);

      assertLiquidateTunaLpPosition(await liquidateTunaLpPosition({ rpc, signer: LIQUIDATOR_KEYPAIR, positionMint }), {
        tunaPositionState: TunaPositionState.ClosedByLimitOrder,
        feeRecipientBalanceDeltaA: 0n,
        feeRecipientBalanceDeltaB: 902458n,
      });
    });
  }

  for (const marketName of marketNames) {
    it(`T/P limit order, swap to token A (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      const positionMint = await openAndIncreaseTunaLpPosition({
        rpc,
        tickLowerIndex: actualTickIndex - pool.data.tickSpacing,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing,
        upperLimitOrderSqrtPrice: tickIndexToSqrtPrice(actualTickIndex + pool.data.tickSpacing * 2),
        pool: pool.address,
        collateralA: 1_000_000_000n,
        collateralB: 100_000_000n,
        borrowA: 2_000_000_000n,
        borrowB: 200_000_000n,
        flags: TUNA_POSITION_FLAGS_UPPER_LIMIT_ORDER_SWAP_TO_TOKEN_A,
      });

      // Move the price.
      await swapExactInput(rpc, signer, pool.address, 10_000_000_000n, pool.data.tokenMintB);

      assertLiquidateTunaLpPosition(await liquidateTunaLpPosition({ rpc, signer: LIQUIDATOR_KEYPAIR, positionMint }), {
        tunaPositionState: TunaPositionState.ClosedByLimitOrder,
        feeRecipientBalanceDeltaA: 0n,
        feeRecipientBalanceDeltaB: 902458n,
      });
    });
  }

  for (const marketName of marketNames) {
    it(`Collect and compound position fees (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const positionMintKeypair = await generateKeyPairSigner();
      const positionMint = positionMintKeypair.address;
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      await openTunaLpPosition({
        signer,
        positionMint: positionMintKeypair,
        pool: pool.address,
        tickLowerIndex: actualTickIndex - pool.data.tickSpacing * 20,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing * 20,
      });

      await increaseTunaLpPosition({
        rpc,
        positionMint,
        pool: pool.address,
        collateralA: 1_000_000_000n,
        collateralB: 0n,
        borrowA: 1_000_000_000n,
        borrowB: 0n,
      });

      // Swap to generate fees
      await swapExactInput(rpc, signer, pool.address, 10_000_000_000n, pool.data.tokenMintA);

      // Without leverage
      assertCollectAndCompoundFees(
        await collectAndCompoundFees({
          rpc,
          signer,
          positionMint,
          pool: pool.address,
          useLeverage: false,
        }),
        {
          vaultBalanceDeltaA: 0n,
          vaultBalanceDeltaB: 0n,
          poolBalanceDeltaA: -21n,
          poolBalanceDeltaB: 15n,
        },
      );

      // Swap to generate fees
      await swapExactInput(rpc, signer, pool.address, 10_000_000_000n, pool.data.tokenMintA);

      // With leverage
      assertCollectAndCompoundFees(
        await collectAndCompoundFees({
          rpc,
          signer,
          positionMint,
          pool: pool.address,
          useLeverage: true,
        }),
        {
          vaultBalanceDeltaA: -20947n,
          vaultBalanceDeltaB: 0n,
          poolBalanceDeltaA: 20902n,
          poolBalanceDeltaB: 0n,
        },
      );

      await decreaseTunaLpPosition({
        rpc,
        signer,
        positionMint,
        pool: pool.address,
        decreasePercent: HUNDRED_PERCENT,
        closeTunaLpPosition: true,
      });
    });
  }

  it("Add and remove liquidity to a pool with double rewards", async () => {
    testOrcaMarket = await setupTestMarket(
      {
        addressLookupTable: DEFAULT_ADDRESS,
        borrowLimitA: 0n,
        borrowLimitB: 0n,
        disabled: false,
        liquidationFee: 10000, // 1%
        liquidationThreshold: 820000, // 82%
        maxLeverage: (LEVERAGE_ONE * 509) / 100,
        unused: 0,
        oraclePriceDeviationThreshold: HUNDRED_PERCENT / 2, // Allow large deviation for tests
        protocolFee: 1000, // 0.1%
        protocolFeeOnCollateral: 1000, // 0.1%
        rebalanceProtocolFee: HUNDRED_PERCENT / 10,
        spotPositionSizeLimitA: 1000_000_000_000,
        spotPositionSizeLimitB: 100000_000_000,
      },
      MarketMaker.Orca,
      {
        initializeRewards: true,
      },
    );

    const whirlpool = await fetchWhirlpool(rpc, testOrcaMarket.pool);
    const actualTickIndex =
      whirlpool.data.tickCurrentIndex - (whirlpool.data.tickCurrentIndex % whirlpool.data.tickSpacing);

    const positionMint = await openAndIncreaseTunaLpPosition({
      rpc,
      tickLowerIndex: actualTickIndex - whirlpool.data.tickSpacing * 5,
      tickUpperIndex: actualTickIndex + whirlpool.data.tickSpacing * 5,
      pool: testOrcaMarket.pool,
      collateralA: 1_000_000_000n,
      collateralB: 1_000_000_000n,
      borrowA: 0n,
      borrowB: 0n,
    });

    // Move time forward
    const testContext = await getTestContext();
    const currentClock = await testContext.banksClient.getClock();
    testContext.setClock(
      new Clock(
        currentClock.slot,
        currentClock.epochStartTimestamp,
        currentClock.epoch,
        currentClock.leaderScheduleEpoch,
        currentClock.unixTimestamp + 3600n,
      ),
    );

    const orcaPositionAddress = (await getPositionAddress(positionMint))[0];
    await updateFeesAndRewards(orcaPositionAddress);

    assertDecreaseTunaLpPositionLiquidity(
      await decreaseTunaLpPosition({
        rpc,
        signer,
        positionMint,
        pool: testOrcaMarket.pool,
        closeTunaLpPosition: true,
      }),
      {
        userRewardBalanceDelta: 28022n,
      },
    );

    // Restore the clock
    testContext.setClock(currentClock);
  });

  for (const marketName of marketNames) {
    it(`Can run openAndIncreaseTunaLpPosition and closeActiveTunaLpPosition (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      const positionMint = await openAndIncreaseTunaLpPosition({
        rpc,
        tickLowerIndex: actualTickIndex - pool.data.tickSpacing * 3,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing * 3,
        pool: pool.address,
        collateralA: 1_000_000_000n,
        collateralB: 0n,
        borrowA: 4_000_000_000n,
        borrowB: 0n,
      });

      await closeActiveTunaLpPosition({ rpc, positionMint });
    });
  }

  for (const marketName of marketNames) {
    it(`Repay debt (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      const positionMint = await openAndIncreaseTunaLpPosition({
        rpc,
        tickLowerIndex: actualTickIndex - pool.data.tickSpacing * 3,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing * 3,
        pool: pool.address,
        collateralA: 1_000_000_000n,
        collateralB: 0n,
        borrowA: 1_000_000_000n,
        borrowB: 1_000_000_000n,
      });

      await repayTunaLpPositionDebt({ rpc, positionMint, collateralA: 10000n, collateralB: 20000n });
    });
  }

  for (const marketName of marketNames) {
    it(`Re-balance a two-sided position (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      const positionMint = await openAndIncreaseTunaLpPosition({
        rpc,
        tickLowerIndex: actualTickIndex - pool.data.tickSpacing * 5,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing * 5,
        pool: pool.address,
        collateralA: 1_000_000_000n,
        collateralB: 1_000_000n,
        borrowA: 2_000_000_000n,
        borrowB: 2_000_000n,
        flags: TUNA_POSITION_FLAGS_ALLOW_REBALANCING,
      });

      // Fails to re-balance the position because re-balance conditions are not met
      await assert.rejects(
        rebalanceTunaLpPosition({
          rpc,
          signer,
          positionMint,
          pool: pool.address,
        }),
        err => {
          expect((err as Error).toString()).contain(
            `custom program error: ${"0x" + TUNA_ERROR__REBALANCE_CONDITIONS_NOT_MET.toString(16)}`,
          );
          return true;
        },
      );

      // Swap and move the price to allow re-balancing.
      await swapExactInput(rpc, signer, pool.address, 100_000_000_000n, market.mintA.address);

      assertRebalanceTunaLpPosition(
        await rebalanceTunaLpPosition({
          rpc,
          signer,
          positionMint,
          pool: pool.address,
        }),
        {
          newTickLowerIndex: -17344,
          newTickUpperIndex: -16704,
        },
      );
    });
  }

  for (const marketName of marketNames) {
    it(`Entry price change on the position increase (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const positionMintKeypair = await generateKeyPairSigner();
      const positionMint = positionMintKeypair.address;
      let pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const positionAddress = (await getTunaLpPositionAddress(positionMint))[0];
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      await openTunaLpPosition({
        signer,
        positionMint: positionMintKeypair,
        pool: pool.address,
        tickLowerIndex: actualTickIndex - pool.data.tickSpacing * 20,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing * 20,
      });

      await increaseTunaLpPosition({
        rpc,
        positionMint,
        pool: pool.address,
        collateralA: 1_000_000n,
        collateralB: 0n,
        borrowA: 1_000_000n,
        borrowB: 0n,
      });

      const position = await fetchTunaLpPosition(rpc, positionAddress);
      pool = await fetchPool(rpc, market.pool, market.marketMaker);

      // Move the price a little
      await swapExactInput(rpc, signer, pool.address, 10000_000_000n, pool.data.tokenMintA);

      await increaseTunaLpPosition({
        rpc,
        positionMint,
        pool: pool.address,
        collateralA: 1_000_000n,
        collateralB: 0n,
        borrowA: 1_000_000n,
        borrowB: 0n,
      });

      const positionAfter = await fetchTunaLpPosition(rpc, positionAddress);
      const poolAfter = await fetchPool(rpc, market.pool, market.marketMaker);

      expect(position.data.entrySqrtPrice).toEqual(pool.data.sqrtPrice);
      expect(position.data.entrySqrtPrice).toEqual(8249631144313578788n);
      expect(positionAfter.data.entrySqrtPrice).toEqual(8231309011612558396n);
      expect(poolAfter.data.sqrtPrice).toEqual(8212909859800077718n);

      await closeActiveTunaLpPosition({ rpc, positionMint });
    });
  }

  for (const marketName of marketNames) {
    it(`Increase and decrease position accounting for direct token transfers (${marketName})`, async () => {
      const market = markets.find(m => m.name == marketName)!;
      const positionMintKeypair = await generateKeyPairSigner();
      const tunaPositionAddress = (await getTunaLpPositionAddress(positionMintKeypair.address))[0];
      const pool = await fetchPool(rpc, market.pool, market.marketMaker);
      const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);

      const signerAtaA = (
        await findAssociatedTokenPda({
          mint: market.mintA.address,
          owner: signer.address,
          tokenProgram: market.mintA.programAddress,
        })
      )[0];

      const signerAtaB = (
        await findAssociatedTokenPda({
          mint: market.mintB.address,
          owner: signer.address,
          tokenProgram: market.mintB.programAddress,
        })
      )[0];

      const tunaPositionAtaA = (
        await findAssociatedTokenPda({
          owner: tunaPositionAddress,
          mint: market.mintA.address,
          tokenProgram: market.mintA.programAddress,
        })
      )[0];

      const tunaPositionAtaB = (
        await findAssociatedTokenPda({
          owner: tunaPositionAddress,
          mint: market.mintB.address,
          tokenProgram: market.mintB.programAddress,
        })
      )[0];

      const transferTokensToThePosition = async () => {
        await sendTransaction([
          getTransferInstruction(
            {
              authority: signer,
              source: signerAtaA,
              destination: tunaPositionAtaA,
              amount: 1_000_000_000n,
            },
            { programAddress: market.mintA.programAddress },
          ),
          getTransferInstruction(
            {
              authority: signer,
              source: signerAtaB,
              destination: tunaPositionAtaB,
              amount: 400_000_000n,
            },
            { programAddress: market.mintB.programAddress },
          ),
        ]);
      };

      await openTunaLpPosition({
        signer,
        positionMint: positionMintKeypair,
        pool: pool.address,
        tickLowerIndex: actualTickIndex - pool.data.tickSpacing * 5,
        tickUpperIndex: actualTickIndex + pool.data.tickSpacing * 5,
      });

      await transferTokensToThePosition();

      assertIncreaseTunaLpPosition(
        await increaseTunaLpPosition({
          rpc,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
          collateralA: 1_000_000_000n,
          collateralB: 0n,
          borrowA: 1_000_000_000n,
          borrowB: 0n,
        }),
        {
          userBalanceDeltaA: -1000000000n,
          userBalanceDeltaB: 0n,
          vaultBalanceDeltaA: -1000000000n,
          vaultBalanceDeltaB: 0n,
          poolBalanceDeltaA: 2997000000n,
          poolBalanceDeltaB: 399599997n,
          leftoversA: 0n,
          leftoversB: 3n,
        },
      );

      await transferTokensToThePosition();

      assertDecreaseTunaLpPositionLiquidity(
        await decreaseTunaLpPosition({
          rpc,
          signer,
          positionMint: positionMintKeypair.address,
          pool: pool.address,
          closeTunaLpPosition: true,
        }),
        {
          userBalanceDeltaA: 2755866254n,
          userBalanceDeltaB: 847807082n,
          vaultBalanceDeltaA: 1000000000n,
          vaultBalanceDeltaB: 0n,
          poolBalanceDeltaA: -2755866254n,
          poolBalanceDeltaB: -447807079n,
        },
      );
    });
  }

  it(`Adds liquidity and lock the position (Fusion)`, async () => {
    const market = testFusionMarket;
    const positionMintKeypair = await generateKeyPairSigner();
    const pool = await fetchPool(rpc, market.pool, market.marketMaker);
    const actualTickIndex = pool.data.tickCurrentIndex - (pool.data.tickCurrentIndex % pool.data.tickSpacing);
    const tunaPositionAddress = (await getTunaLpPositionAddress(positionMintKeypair.address))[0];

    await openTunaLpPosition({
      signer,
      positionMint: positionMintKeypair,
      pool: pool.address,
      tickLowerIndex: actualTickIndex - pool.data.tickSpacing * 5,
      tickUpperIndex: actualTickIndex + pool.data.tickSpacing * 5,
    });

    await increaseTunaLpPosition({
      rpc,
      positionMint: positionMintKeypair.address,
      pool: pool.address,
      collateralA: 1_000_000_000n,
      collateralB: 0n,
      borrowA: 0n,
      borrowB: 0n,
    });

    await sendTransaction([
      getSetTunaLpPositionFlagsInstruction({
        authority: signer,
        flags: TUNA_POSITION_FLAGS_LOCKED,
        tunaPosition: tunaPositionAddress,
      }),
    ]);

    // Fails to remove the lock
    await assert.rejects(
      sendTransaction([
        getSetTunaLpPositionFlagsInstruction({
          authority: signer,
          flags: 0,
          tunaPosition: tunaPositionAddress,
        }),
      ]),
      err => {
        expect((err as Error).toString()).contain(
          `custom program error: ${"0x" + TUNA_ERROR__POSITION_LOCKED.toString(16)}`,
        );
        return true;
      },
    );

    // Fails to set limit orders
    await assert.rejects(
      sendTransaction([
        await setTunaLpPositionLimitOrdersInstruction(
          signer,
          {
            lowerLimitOrderSqrtPrice: priceToSqrtPrice(190, 9, 6),
            upperLimitOrderSqrtPrice: priceToSqrtPrice(220, 9, 6),
            swapToTokenOnLimitOrder:
              TUNA_POSITION_FLAGS_LOWER_LIMIT_ORDER_SWAP_TO_TOKEN_B |
              TUNA_POSITION_FLAGS_UPPER_LIMIT_ORDER_SWAP_TO_TOKEN_A,
          },
          undefined,
          tunaPositionAddress,
        ),
      ]),
      err => {
        expect((err as Error).toString()).contain(
          `custom program error: ${"0x" + TUNA_ERROR__POSITION_LOCKED.toString(16)}`,
        );
        return true;
      },
    );

    // Can increase
    await increaseTunaLpPosition({
      rpc,
      positionMint: positionMintKeypair.address,
      pool: pool.address,
      collateralA: 1_000_000_000n,
      collateralB: 0n,
      borrowA: 0n,
      borrowB: 0n,
    });

    // Can't increase with borrowed funds
    await assert.rejects(
      increaseTunaLpPosition({
        rpc,
        positionMint: positionMintKeypair.address,
        pool: pool.address,
        collateralA: 1_000_000_000n,
        collateralB: 0n,
        borrowA: 1_000_000_000n,
        borrowB: 0n,
      }),
      err => {
        expect((err as Error).toString()).contain(
          `custom program error: ${"0x" + TUNA_ERROR__LEVERAGED_LOCKED_POSITION_NOT_ALLOWED.toString(16)}`,
        );
        return true;
      },
    );

    await assert.rejects(
      decreaseTunaLpPosition({
        rpc,
        signer,
        positionMint: positionMintKeypair.address,
        pool: pool.address,
        closeTunaLpPosition: false,
      }),
      err => {
        expect((err as Error).toString()).contain(
          `custom program error: ${"0x" + TUNA_ERROR__POSITION_LOCKED.toString(16)}`,
        );
        return true;
      },
    );
  });
}, 20000);
