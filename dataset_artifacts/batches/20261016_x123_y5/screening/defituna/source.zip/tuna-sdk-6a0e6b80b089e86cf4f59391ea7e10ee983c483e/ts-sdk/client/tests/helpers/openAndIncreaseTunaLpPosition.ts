import { Address, generateKeyPairSigner, Rpc, SolanaRpcApi, TransactionSigner } from "@solana/kit";
import { getSetComputeUnitLimitInstruction } from "@solana-program/compute-budget";
import { fetchMaybeToken, fetchMint, findAssociatedTokenPda } from "@solana-program/token-2022";
import { expect } from "vitest";

import {
  fetchMarket,
  fetchTunaConfig,
  fetchVault,
  getMarketAddress,
  getTunaConfigAddress,
  HUNDRED_PERCENT,
  MarketMaker,
  MAX_SQRT_PRICE,
  MIN_SQRT_PRICE,
  openAndIncreaseTunaLpPositionFusionInstructions,
  openAndIncreaseTunaLpPositionOrcaInstructions,
} from "../../src";

import { FUNDER } from "./addresses.ts";
import { fetchPool } from "./fetch.ts";
import { sendTransaction } from "./mockRpc.ts";

export type OpenAndIncreaseLpPositionTestArgs = {
  rpc: Rpc<SolanaRpcApi>;
  signer?: TransactionSigner;
  pool: Address;
  tickLowerIndex: number;
  tickUpperIndex: number;
  lowerLimitOrderSqrtPrice?: bigint;
  upperLimitOrderSqrtPrice?: bigint;
  flags?: number;
  collateralA: bigint;
  collateralB: bigint;
  borrowA: bigint;
  borrowB: bigint;
};

export async function openAndIncreaseTunaLpPosition({
  rpc,
  pool: poolAddress,
  collateralA,
  collateralB,
  borrowA,
  borrowB,
  tickLowerIndex,
  tickUpperIndex,
  lowerLimitOrderSqrtPrice,
  upperLimitOrderSqrtPrice,
  flags,
  signer = FUNDER,
}: OpenAndIncreaseLpPositionTestArgs) {
  const tunaConfigAddress = (await getTunaConfigAddress())[0];
  const tunaConfig = await fetchTunaConfig(rpc, tunaConfigAddress);
  const marketAddress = (await getMarketAddress(poolAddress))[0];
  const market = await fetchMarket(rpc, marketAddress);
  const pool = await fetchPool(rpc, poolAddress, market.data.marketMaker);
  const mintA = await fetchMint(rpc, pool.data.tokenMintA);
  const mintB = await fetchMint(rpc, pool.data.tokenMintB);

  const vaultAAddress = market.data.vaultA;
  const vaultA = await fetchVault(rpc, vaultAAddress);

  const vaultBAddress = market.data.vaultB;
  const vaultB = await fetchVault(rpc, vaultBAddress);

  const feeRecipientAtaA = (
    await findAssociatedTokenPda({
      owner: tunaConfig.data.feeRecipient,
      mint: mintA.address,
      tokenProgram: mintA.programAddress,
    })
  )[0];

  const feeRecipientAtaB = (
    await findAssociatedTokenPda({
      owner: tunaConfig.data.feeRecipient,
      mint: mintB.address,
      tokenProgram: mintB.programAddress,
    })
  )[0];

  const openTunaLpPositionArgs = {
    tickLowerIndex,
    tickUpperIndex,
    lowerLimitOrderSqrtPrice: lowerLimitOrderSqrtPrice ?? MIN_SQRT_PRICE,
    upperLimitOrderSqrtPrice: upperLimitOrderSqrtPrice ?? MAX_SQRT_PRICE,
    flags: flags ?? 0,
    borrowA,
    borrowB,
    collateralA,
    collateralB,
    minAddedAmountA: 0n,
    minAddedAmountB: 0n,
  };

  const positionMint = await generateKeyPairSigner();
  const ix =
    market.data.marketMaker == MarketMaker.Orca
      ? await openAndIncreaseTunaLpPositionOrcaInstructions(
          rpc,
          signer,
          positionMint,
          poolAddress,
          openTunaLpPositionArgs,
        )
      : await openAndIncreaseTunaLpPositionFusionInstructions(
          rpc,
          signer,
          positionMint,
          poolAddress,
          openTunaLpPositionArgs,
        );

  ix.instructions.unshift(getSetComputeUnitLimitInstruction({ units: 1_400_000 }));

  const feeRecipientTokenABefore = await fetchMaybeToken(rpc, feeRecipientAtaA);
  const feeRecipientBalanceABefore = feeRecipientTokenABefore.exists ? feeRecipientTokenABefore.data.amount : 0n;
  const feeRecipientTokenBBefore = await fetchMaybeToken(rpc, feeRecipientAtaB);
  const feeRecipientBalanceBBefore = feeRecipientTokenBBefore.exists ? feeRecipientTokenBBefore.data.amount : 0n;

  await sendTransaction(ix.instructions);

  const marketAfter = await fetchMarket(rpc, marketAddress);
  expect(marketAfter.data.borrowedSharesA - market.data.borrowedSharesA).toEqual(borrowA);
  expect(marketAfter.data.borrowedSharesB - market.data.borrowedSharesB).toEqual(borrowB);

  const feeRecipientTokenAAfter = await fetchMaybeToken(rpc, feeRecipientAtaA);
  const feeRecipientBalanceAAfter = feeRecipientTokenAAfter.exists ? feeRecipientTokenAAfter.data.amount : 0n;
  const feeRecipientTokenBAfter = await fetchMaybeToken(rpc, feeRecipientAtaB);
  const feeRecipientBalanceBAfter = feeRecipientTokenBAfter.exists ? feeRecipientTokenBAfter.data.amount : 0n;

  const vaultAAfter = await fetchVault(rpc, vaultAAddress);
  const vaultBAfter = await fetchVault(rpc, vaultBAddress);
  expect(vaultAAfter.data.borrowedShares - vaultA.data.borrowedShares).toEqual(borrowA);
  expect(vaultBAfter.data.borrowedShares - vaultB.data.borrowedShares).toEqual(borrowB);

  const feeA =
    (collateralA * BigInt(market.data.protocolFeeOnCollateral) + borrowA * BigInt(market.data.protocolFee)) /
    BigInt(HUNDRED_PERCENT);
  const feeB =
    (collateralB * BigInt(market.data.protocolFeeOnCollateral) + borrowB * BigInt(market.data.protocolFee)) /
    BigInt(HUNDRED_PERCENT);
  expect(feeRecipientBalanceAAfter - feeRecipientBalanceABefore).toEqual(feeA);
  expect(feeRecipientBalanceBAfter - feeRecipientBalanceBBefore).toEqual(feeB);
  expect(marketAfter.data.numPositions).toEqual(market.data.numPositions + 1);

  return positionMint.address;
}
