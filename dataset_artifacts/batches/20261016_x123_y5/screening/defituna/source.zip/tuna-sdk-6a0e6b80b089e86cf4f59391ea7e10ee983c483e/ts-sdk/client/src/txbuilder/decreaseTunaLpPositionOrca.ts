import {
  fetchAllTickArray,
  fetchMaybeWhirlpool,
  fetchPosition,
  getOracleAddress,
  getPositionAddress,
  getTickArrayAddress,
  Whirlpool,
  WHIRLPOOL_PROGRAM_ADDRESS,
} from "@orca-so/whirlpools-client";
import { collectRewardsQuote, getTickArrayStartTickIndex, getTickIndexInArray } from "@orca-so/whirlpools-core";
import {
  type Account,
  AccountRole,
  Address,
  assertAccountsExist,
  GetAccountInfoApi,
  GetMultipleAccountsApi,
  IAccountMeta,
  IInstruction,
  Rpc,
  TransactionSigner,
} from "@solana/kit";
import { MEMO_PROGRAM_ADDRESS } from "@solana-program/memo";
import {
  fetchAllMaybeMint,
  fetchMaybeToken,
  findAssociatedTokenPda,
  Mint,
  TOKEN_2022_PROGRAM_ADDRESS,
} from "@solana-program/token-2022";
import assert from "assert";

import {
  AccountsType,
  DecreaseTunaLpPositionOrcaInstructionDataArgs,
  DEFAULT_ADDRESS,
  fetchAllVault,
  fetchMarket,
  fetchMaybeTunaLpPosition,
  getCreateAtaInstructions,
  getDecreaseTunaLpPositionOrcaInstruction,
  getMarketAddress,
  getTunaConfigAddress,
  getTunaLpPositionAddress,
  OrcaUtils,
  TunaLpPosition,
  Vault,
} from "../index.ts";

export type DecreaseTunaLpPositionOrcaInstructionsArgs = Omit<
  DecreaseTunaLpPositionOrcaInstructionDataArgs,
  "remainingAccountsInfo" | "unused"
>;

export async function decreaseTunaLpPositionOrcaInstructions(
  rpc: Rpc<GetAccountInfoApi & GetMultipleAccountsApi>,
  authority: TransactionSigner,
  positionMint: Address,
  args: DecreaseTunaLpPositionOrcaInstructionsArgs,
  createInstructions?: IInstruction[],
  cleanupInstructions?: IInstruction[],
): Promise<IInstruction[]> {
  const init: IInstruction[] = [];
  const cleanup: IInstruction[] = [];

  const tunaPosition = await fetchMaybeTunaLpPosition(rpc, (await getTunaLpPositionAddress(positionMint))[0]);
  if (!tunaPosition.exists) throw new Error("Tuna position account not found");

  const orcaPosition = await fetchPosition(rpc, (await getPositionAddress(positionMint))[0]);

  const whirlpool = await fetchMaybeWhirlpool(rpc, tunaPosition.data.pool);
  if (!whirlpool.exists) throw new Error("Whirlpool account not found");

  const marketAddress = (await getMarketAddress(tunaPosition.data.pool))[0];
  const market = await fetchMarket(rpc, marketAddress);

  const [vaultA, vaultB] = await fetchAllVault(rpc, [market.data.vaultA, market.data.vaultB]);

  const [mintA, mintB, ...rewardMints] = await fetchAllMaybeMint(rpc, [
    whirlpool.data.tokenMintA,
    whirlpool.data.tokenMintB,
    ...whirlpool.data.rewardInfos.map(x => x.mint).filter(x => x !== DEFAULT_ADDRESS),
  ]);
  const allMints = [mintA, mintB, ...rewardMints];

  assert(mintA.exists, "Token A account not found");
  assert(mintB.exists, "Token B account not found");
  assertAccountsExist(rewardMints);

  const lowerTickArrayStartIndex = getTickArrayStartTickIndex(
    tunaPosition.data.tickLowerIndex,
    whirlpool.data.tickSpacing,
  );
  const [lowerTickArrayAddress] = await getTickArrayAddress(whirlpool.address, lowerTickArrayStartIndex);

  const upperTickArrayStartIndex = getTickArrayStartTickIndex(
    tunaPosition.data.tickUpperIndex,
    whirlpool.data.tickSpacing,
  );
  const [upperTickArrayAddress] = await getTickArrayAddress(whirlpool.address, upperTickArrayStartIndex);

  const [lowerTickArray, upperTickArray] = await fetchAllTickArray(rpc, [lowerTickArrayAddress, upperTickArrayAddress]);

  const lowerTick =
    lowerTickArray.data.ticks[
      getTickIndexInArray(tunaPosition.data.tickLowerIndex, lowerTickArrayStartIndex, whirlpool.data.tickSpacing)
    ];
  const upperTick =
    upperTickArray.data.ticks[
      getTickIndexInArray(tunaPosition.data.tickUpperIndex, upperTickArrayStartIndex, whirlpool.data.tickSpacing)
    ];

  //
  // Add token account creation instructions for every mint if needed.
  //

  const rewardsToClaim: number[] = [];
  const requiredMints: Address[] = [];
  requiredMints.push(whirlpool.data.tokenMintA);
  requiredMints.push(whirlpool.data.tokenMintB);

  let currentUnixTimestamp = BigInt(Math.floor(Date.now() / 1000));
  // It may happen in tests or in case of a wrong date.
  if (currentUnixTimestamp < whirlpool.data.rewardLastUpdatedTimestamp)
    currentUnixTimestamp = whirlpool.data.rewardLastUpdatedTimestamp;

  const rewardsQuote = collectRewardsQuote(
    whirlpool.data,
    orcaPosition.data,
    lowerTick,
    upperTick,
    currentUnixTimestamp,
  );

  for (let i = 0; i < rewardsQuote.rewards.length; i++) {
    if (rewardsQuote.rewards[i].rewardsOwed > 0n) {
      requiredMints.push(whirlpool.data.rewardInfos[i].mint);
      rewardsToClaim.push(i);
    }
  }

  for (const mintAddress of requiredMints) {
    const mint = allMints.find(mint => mint.address == mintAddress);
    assert(mint && mint.exists);

    const ata = (
      await findAssociatedTokenPda({
        owner: authority.address,
        mint: mint.address,
        tokenProgram: mint.programAddress,
      })
    )[0];

    const tokenAccount = await fetchMaybeToken(rpc, ata);
    if (!tokenAccount.exists) {
      const instructions = await getCreateAtaInstructions(
        rpc,
        authority,
        mint.address,
        authority.address,
        mint.programAddress,
      );
      init.push(...instructions.init);
      cleanup.push(...instructions.cleanup);
    }
  }

  //
  // Create the list of instructions
  //
  const instructions: IInstruction[] = [];

  if (createInstructions) {
    createInstructions.push(...init);
  } else {
    instructions.push(...init);
  }

  //
  // Finally, add liquidity decrease instruction.
  //

  const ix = await decreaseTunaLpPositionOrcaInstruction(
    authority,
    tunaPosition,
    mintA,
    mintB,
    vaultA,
    vaultB,
    whirlpool,
    rewardsToClaim,
    rewardMints,
    { ...args },
  );
  instructions.push(ix);

  //
  // Close WSOL accounts if needed.
  //

  if (cleanupInstructions) {
    cleanupInstructions.push(...cleanup);
  } else {
    instructions.push(...cleanup);
  }

  return instructions;
}

export async function decreaseTunaLpPositionOrcaInstruction(
  authority: TransactionSigner,
  tunaPosition: Account<TunaLpPosition>,
  mintA: Account<Mint>,
  mintB: Account<Mint>,
  vaultA: Account<Vault>,
  vaultB: Account<Vault>,
  whirlpool: Account<Whirlpool>,
  rewardIndicesToClaim: number[],
  rewardMints: Account<Mint>[],
  args: Omit<DecreaseTunaLpPositionOrcaInstructionDataArgs, "remainingAccountsInfo" | "unused">,
): Promise<IInstruction> {
  const positionMint = tunaPosition.data.positionMint;

  const tunaConfig = (await getTunaConfigAddress())[0];
  const marketAddress = (await getMarketAddress(whirlpool.address))[0];
  const orcaPositionAddress = (await getPositionAddress(positionMint))[0];
  const orcaOracleAddress = (await getOracleAddress(whirlpool.address))[0];

  const tunaPositionAta = (
    await findAssociatedTokenPda({
      owner: tunaPosition.address,
      mint: positionMint,
      tokenProgram: TOKEN_2022_PROGRAM_ADDRESS,
    })
  )[0];

  const tunaPositionOwnerAtaA = (
    await findAssociatedTokenPda({
      owner: authority.address,
      mint: mintA.address,
      tokenProgram: mintA.programAddress,
    })
  )[0];

  const tunaPositionOwnerAtaB = (
    await findAssociatedTokenPda({
      owner: authority.address,
      mint: mintB.address,
      tokenProgram: mintB.programAddress,
    })
  )[0];

  const tunaPositionAtaA = (
    await findAssociatedTokenPda({
      owner: tunaPosition.address,
      mint: mintA.address,
      tokenProgram: mintA.programAddress,
    })
  )[0];

  const tunaPositionAtaB = (
    await findAssociatedTokenPda({
      owner: tunaPosition.address,
      mint: mintB.address,
      tokenProgram: mintB.programAddress,
    })
  )[0];

  const vaultAAta = (
    await findAssociatedTokenPda({
      owner: vaultA.address,
      mint: mintA.address,
      tokenProgram: mintA.programAddress,
    })
  )[0];

  const vaultBAta = (
    await findAssociatedTokenPda({
      owner: vaultB.address,
      mint: mintB.address,
      tokenProgram: mintB.programAddress,
    })
  )[0];

  const swapTickArrays = await OrcaUtils.getSwapTickArrayAddresses(whirlpool);
  const lowerTickArrayAddress = await OrcaUtils.getTickArrayAddressFromTickIndex(
    whirlpool,
    tunaPosition.data.tickLowerIndex,
  );
  const upperTickArrayAddress = await OrcaUtils.getTickArrayAddressFromTickIndex(
    whirlpool,
    tunaPosition.data.tickUpperIndex,
  );

  const remainingAccounts: IAccountMeta[] = [
    { address: swapTickArrays[0], role: AccountRole.WRITABLE },
    { address: swapTickArrays[1], role: AccountRole.WRITABLE },
    { address: swapTickArrays[2], role: AccountRole.WRITABLE },
    { address: swapTickArrays[3], role: AccountRole.WRITABLE },
    { address: swapTickArrays[4], role: AccountRole.WRITABLE },
    { address: lowerTickArrayAddress, role: AccountRole.WRITABLE },
    { address: upperTickArrayAddress, role: AccountRole.WRITABLE },
    { address: whirlpool.data.tokenVaultA, role: AccountRole.WRITABLE },
    { address: whirlpool.data.tokenVaultB, role: AccountRole.WRITABLE },
    { address: orcaOracleAddress, role: AccountRole.WRITABLE },
  ];

  for (const rewardIndex of rewardIndicesToClaim) {
    const rewardInfo = whirlpool.data.rewardInfos[rewardIndex];
    const rewardMint = rewardMints.find(mint => mint.address == rewardInfo.mint);
    assert(rewardMint, "Reward mint not found in the provided reward mint accounts");

    const ownerAta = await findAssociatedTokenPda({
      owner: authority.address,
      mint: rewardMint.address,
      tokenProgram: rewardMint.programAddress,
    });

    remainingAccounts.push({ address: rewardMint.address, role: AccountRole.READONLY });
    remainingAccounts.push({ address: rewardMint.programAddress, role: AccountRole.READONLY });
    remainingAccounts.push({ address: ownerAta[0], role: AccountRole.WRITABLE });
    remainingAccounts.push({ address: rewardInfo.vault, role: AccountRole.WRITABLE });
  }

  const remainingAccountsInfo = {
    slices: [
      { accountsType: AccountsType.SwapTickArrays, length: 5 },
      { accountsType: AccountsType.TickArrayLower, length: 1 },
      { accountsType: AccountsType.TickArrayUpper, length: 1 },
      { accountsType: AccountsType.PoolVaultTokenA, length: 1 },
      { accountsType: AccountsType.PoolVaultTokenB, length: 1 },
      { accountsType: AccountsType.WhirlpoolOracle, length: 1 },
    ],
  };
  if (rewardIndicesToClaim.length > 0) {
    remainingAccountsInfo.slices.push({ accountsType: AccountsType.Rewards, length: 4 * rewardIndicesToClaim.length });
  }

  const ix = getDecreaseTunaLpPositionOrcaInstruction({
    market: marketAddress,
    mintA: mintA.address,
    mintB: mintB.address,
    oraclePriceUpdateA: vaultA.data.oraclePriceUpdate,
    oraclePriceUpdateB: vaultB.data.oraclePriceUpdate,
    vaultA: vaultA.address,
    vaultAAta,
    vaultB: vaultB.address,
    vaultBAta,
    authority,
    tunaConfig,
    tunaPositionAta,
    tunaPositionAtaA,
    tunaPositionAtaB,
    tunaPositionOwnerAtaA,
    tunaPositionOwnerAtaB,
    orcaPosition: orcaPositionAddress,
    tunaPosition: tunaPosition.address,
    whirlpool: whirlpool.address,
    whirlpoolProgram: WHIRLPOOL_PROGRAM_ADDRESS,
    tokenProgramA: mintA.programAddress,
    tokenProgramB: mintB.programAddress,
    memoProgram: MEMO_PROGRAM_ADDRESS,
    ...args,
    unused: 0,
    remainingAccountsInfo,
  });

  // @ts-expect-error don't worry about the error
  ix.accounts.push(...remainingAccounts);

  return ix;
}
