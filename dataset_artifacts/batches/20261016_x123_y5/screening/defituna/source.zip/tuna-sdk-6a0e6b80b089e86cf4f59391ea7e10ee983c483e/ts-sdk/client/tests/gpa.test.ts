import type { Address, GetProgramAccountsMemcmpFilter, ReadonlyUint8Array } from "@solana/kit";
import {
  createDefaultRpcTransport,
  createSolanaRpcFromTransport,
  getAddressDecoder,
  getBase58Encoder,
} from "@solana/kit";
import { afterEach, assert, beforeEach, describe, it, vi } from "vitest";

import {
  fetchAllLendingPositionWithFilter,
  fetchAllMarketWithFilter,
  fetchAllReferralsWithFilter,
  fetchAllTunaLpPositionWithFilter,
  fetchAllTunaSpotPositionWithFilter,
  getLendingPositionEncoder,
  getMarketEncoder,
  getReferralEncoder,
  getTunaLpPositionEncoder,
  getTunaSpotPositionEncoder,
  LendingPositionArgs,
  lendingPositionAuthorityFilter,
  lendingPositionMintFilter,
  lendingPositionVaultFilter,
  MarketArgs,
  marketAuthorityFilter,
  MarketMaker,
  marketMarketMakerFilter,
  PoolToken,
  ReferralArgs,
  referralAuthorityFilter,
  referralIdFilter,
  TunaLpPositionArgs,
  tunaLpPositionAuthorityFilter,
  tunaLpPositionMarketMakerFilter,
  tunaLpPositionMintAFilter,
  tunaLpPositionMintBFilter,
  tunaLpPositionMintFilter,
  tunaLpPositionPoolFilter,
  TunaPositionState,
  TunaSpotPositionArgs,
  tunaSpotPositionAuthorityFilter,
  tunaSpotPositionMintAFilter,
  tunaSpotPositionMintBFilter,
  tunaSpotPositionPoolFilter,
} from "../src";
import { fetchDecodedProgramAccounts } from "../src/gpa/utils";

describe("Get program account memcmp filters", () => {
  const mockRpc = createSolanaRpcFromTransport(createDefaultRpcTransport({ url: "" }));
  const addresses: Address[] = [...Array(25).keys()].map(i => {
    const bytes = Array.from({ length: 32 }, () => i);
    return getAddressDecoder().decode(new Uint8Array(bytes));
  });

  beforeEach(() => {
    vi.mock("../src/gpa/utils", () => ({
      fetchDecodedProgramAccounts: vi.fn().mockResolvedValue([]),
    }));
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  function assertFilters(data: ReadonlyUint8Array) {
    const mockFetch = vi.mocked(fetchDecodedProgramAccounts);
    const filters = mockFetch.mock.calls[0][2] as GetProgramAccountsMemcmpFilter[];
    for (const filter of filters) {
      const offset = Number(filter.memcmp.offset);
      const actual = getBase58Encoder().encode(filter.memcmp.bytes);
      const expected = data.subarray(offset, offset + actual.length);
      assert.deepStrictEqual(actual, expected);
    }
  }

  it("Market", async () => {
    const marketStruct: MarketArgs = {
      addressLookupTable: addresses[0],
      badDebtA: 343423,
      badDebtB: 136653,
      borrowLimitA: 245773,
      borrowLimitB: 34465763,
      borrowedSharesA: 2355,
      borrowedSharesB: 23576,
      bump: new Uint8Array(),
      disabled: false,
      liquidationFee: 0,
      liquidationThreshold: 0,
      marketMaker: MarketMaker.Fusion,
      maxLeverage: 0,
      numPositions: 0,
      oraclePriceDeviationThreshold: 0,
      pool: addresses[1],
      protocolFee: 0,
      protocolFeeOnCollateral: 0,
      rebalanceProtocolFee: 0,
      reserved: new Uint8Array(),
      spotPositionSizeLimitA: 653378789,
      spotPositionSizeLimitB: 4573568,
      unused1: 0,
      vaultA: addresses[2],
      vaultB: addresses[3],
      version: 1,
      authority: addresses[4],
    };
    await fetchAllMarketWithFilter(
      mockRpc,
      marketMarketMakerFilter(marketStruct.marketMaker),
      marketAuthorityFilter(marketStruct.authority),
    );
    const data = getMarketEncoder().encode(marketStruct);
    assertFilters(data);
  });

  it("LendingPosition", async () => {
    const positionStruct: LendingPositionArgs = {
      version: 1,
      bump: new Uint8Array(),
      authority: addresses[0],
      mint: addresses[1],
      depositedFunds: 3442662,
      depositedShares: 28643,
      vault: addresses[2],
      reserved: new Uint8Array(),
    };
    await fetchAllLendingPositionWithFilter(
      mockRpc,
      lendingPositionAuthorityFilter(positionStruct.authority),
      lendingPositionMintFilter(positionStruct.mint),
      lendingPositionVaultFilter(positionStruct.vault),
    );
    const data = getLendingPositionEncoder().encode(positionStruct);
    assertFilters(data);
  });

  it("TunaLpPosition", async () => {
    const positionStruct: TunaLpPositionArgs = {
      version: 1,
      bump: new Uint8Array(),
      authority: addresses[0],
      pool: addresses[1],
      mintA: addresses[2],
      mintB: addresses[3],
      positionMint: addresses[4],
      compoundedYieldA: 56388,
      compoundedYieldB: 63462,
      flags: 4,
      leftoversA: 36,
      leftoversB: 88,
      liquidity: 7243345656,
      loanFundsA: 9531733,
      loanFundsB: 39840566,
      loanSharesA: 124574676,
      loanSharesB: 372268,
      marketMaker: 1,
      state: TunaPositionState.Liquidated,
      tickLowerIndex: 3112,
      tickUpperIndex: 8010,
      tickEntryIndex: 0,
      tickStopLossIndex: 0,
      tickTakeProfitIndex: 0,
      entrySqrtPrice: 2333252n,
      lowerLimitOrderSqrtPrice: 4575467535n,
      upperLimitOrderSqrtPrice: 85523525n,
      unused1: 0,
      rebalanceThresholdTicks: 0,
      reserved: new Uint8Array(),
    };
    await fetchAllTunaLpPositionWithFilter(
      mockRpc,
      tunaLpPositionAuthorityFilter(positionStruct.authority),
      tunaLpPositionPoolFilter(positionStruct.pool),
      tunaLpPositionMintAFilter(positionStruct.mintA),
      tunaLpPositionMintBFilter(positionStruct.mintB),
      tunaLpPositionMintFilter(positionStruct.positionMint),
      tunaLpPositionMarketMakerFilter(positionStruct.marketMaker),
    );
    const data = getTunaLpPositionEncoder().encode(positionStruct);
    assertFilters(data);
  });

  it("TunaSpotPosition", async () => {
    const positionStruct: TunaSpotPositionArgs = {
      version: 1,
      bump: new Uint8Array(),
      authority: addresses[0],
      pool: addresses[1],
      mintA: addresses[2],
      mintB: addresses[3],
      amount: 243432545922n,
      collateralToken: PoolToken.A,
      positionToken: PoolToken.B,
      entrySqrtPrice: 788346543523n,
      flags: 0,
      loanFunds: 352345827769n,
      loanShares: 12431242454325n,
      marketMaker: MarketMaker.Fusion,
      lowerLimitOrderSqrtPrice: 235945354895346n,
      upperLimitOrderSqrtPrice: 465839457485485n,
      reserved: new Uint8Array(),
    };
    await fetchAllTunaSpotPositionWithFilter(
      mockRpc,
      tunaSpotPositionAuthorityFilter(positionStruct.authority),
      tunaSpotPositionPoolFilter(positionStruct.pool),
      tunaSpotPositionMintAFilter(positionStruct.mintA),
      tunaSpotPositionMintBFilter(positionStruct.mintB),
    );
    const data = getTunaSpotPositionEncoder().encode(positionStruct);
    assertFilters(data);
  });

  it("Referral", async () => {
    const referralStruct: ReferralArgs = {
      authority: addresses[0],
      timestamp: 43637432452,
      referralId: 4676484,
      reserved: new Uint8Array(),
    };
    await fetchAllReferralsWithFilter(
      mockRpc,
      referralAuthorityFilter(referralStruct.authority),
      referralIdFilter(referralStruct.referralId),
    );
    const data = getReferralEncoder().encode(referralStruct);
    assertFilters(data);
  });
});
