import { FusionPool } from "@crypticdot/fusionamm-client";
import { Whirlpool } from "@orca-so/whirlpools-client";
import {
  Account,
  Address,
  IAccountMeta,
  IInstruction,
  type ReadonlyUint8Array,
  Rpc,
  SolanaRpcApi,
  TransactionSigner,
} from "@solana/kit";
import { fetchMaybeToken, fetchMint, fetchToken, findAssociatedTokenPda } from "@solana-program/token-2022";
import { assert, expect } from "vitest";

import {
  fetchMarket,
  fetchTunaConfig,
  fetchTunaLpPosition,
  fetchVault,
  getMarketAddress,
  getTunaConfigAddress,
  getTunaLpPositionAddress,
  HUNDRED_PERCENT,
  liquidateTunaLpPositionFusionJupiterInstructions,
  liquidateTunaLpPositionOrcaJupiterInstructions,
  MarketMaker,
} from "../../src";

import { fetchPool, fetchPosition, getPositionAddress } from "./fetch.ts";
import { LiquidateTunaLpPositionTestResults } from "./liquidateTunaLpPosition.ts";
import { sendTransaction } from "./mockRpc.ts";

export type LiquidateTunaLpPositionJupiterTestArgs = {
  rpc: Rpc<SolanaRpcApi>;
  signer: TransactionSigner;
  positionMint: Address;
  decreasePercent?: number;
  routeAccounts: IAccountMeta[];
  routeData: ReadonlyUint8Array;
};

export async function liquidateTunaLpPositionJupiter({
  rpc,
  signer,
  positionMint,
  decreasePercent,
  routeAccounts,
  routeData,
}: LiquidateTunaLpPositionJupiterTestArgs): Promise<LiquidateTunaLpPositionTestResults> {
  const tunaConfigAddress = (await getTunaConfigAddress())[0];
  const tunaConfig = await fetchTunaConfig(rpc, tunaConfigAddress);
  const tunaPositionAddress = (await getTunaLpPositionAddress(positionMint))[0];
  const tunaPosition = await fetchTunaLpPosition(rpc, tunaPositionAddress);

  const marketAddress = (await getMarketAddress(tunaPosition.data.pool))[0];
  const market = await fetchMarket(rpc, marketAddress);
  const pool = await fetchPool(rpc, tunaPosition.data.pool, market.data.marketMaker);

  const mintA = await fetchMint(rpc, pool.data.tokenMintA);
  const mintB = await fetchMint(rpc, pool.data.tokenMintB);

  const positionAddress = (await getPositionAddress(positionMint, market.data.marketMaker))[0];

  const tunaPositionAtaA = (
    await findAssociatedTokenPda({
      owner: tunaPositionAddress,
      mint: mintA.address,
      tokenProgram: mintA.programAddress,
    })
  )[0];

  const tunaPositionAtaB = (
    await findAssociatedTokenPda({
      owner: tunaPositionAddress,
      mint: mintB.address,
      tokenProgram: mintB.programAddress,
    })
  )[0];

  const vaultAAddress = market.data.vaultA;
  const vaultAAta = (
    await findAssociatedTokenPda({
      owner: vaultAAddress,
      mint: mintA.address,
      tokenProgram: mintA.programAddress,
    })
  )[0];
  const vaultA = await fetchVault(rpc, vaultAAddress);

  const vaultBAddress = market.data.vaultB;
  const vaultBAta = (
    await findAssociatedTokenPda({
      owner: vaultBAddress,
      mint: mintB.address,
      tokenProgram: mintB.programAddress,
    })
  )[0];
  const vaultB = await fetchVault(rpc, vaultBAddress);

  const feeRecipientAAta = (
    await findAssociatedTokenPda({
      owner: tunaConfig.data.feeRecipient,
      mint: mintA.address,
      tokenProgram: mintA.programAddress,
    })
  )[0];
  const feeRecipientBAta = (
    await findAssociatedTokenPda({
      owner: tunaConfig.data.feeRecipient,
      mint: mintB.address,
      tokenProgram: mintB.programAddress,
    })
  )[0];

  let instructions: IInstruction[];
  if (market.data.marketMaker == MarketMaker.Orca) {
    instructions = await liquidateTunaLpPositionOrcaJupiterInstructions(
      signer,
      tunaPosition,
      tunaConfig,
      mintA,
      mintB,
      vaultA,
      vaultB,
      pool as Account<Whirlpool>,
      routeAccounts,
      {
        decreasePercent: decreasePercent ?? HUNDRED_PERCENT,
        jupiterRouteData: routeData,
      },
    );
  } else {
    instructions = await liquidateTunaLpPositionFusionJupiterInstructions(
      signer,
      tunaPosition,
      tunaConfig,
      mintA,
      mintB,
      vaultA,
      vaultB,
      pool as Account<FusionPool>,
      routeAccounts,
      {
        decreasePercent: decreasePercent ?? HUNDRED_PERCENT,
        jupiterRouteData: routeData,
      },
    );
  }

  const vaultABalanceBefore = (await fetchToken(rpc, vaultAAta)).data.amount;
  const vaultBBalanceBefore = (await fetchToken(rpc, vaultBAta)).data.amount;
  const poolBalanceABefore = (await fetchToken(rpc, pool.data.tokenVaultA)).data.amount;
  const poolBalanceBBefore = (await fetchToken(rpc, pool.data.tokenVaultB)).data.amount;
  const feeRecipientTokenABefore = await fetchMaybeToken(rpc, feeRecipientAAta);
  const feeRecipientBalanceABefore = feeRecipientTokenABefore.exists ? feeRecipientTokenABefore.data.amount : 0n;
  const feeRecipientTokenBBefore = await fetchMaybeToken(rpc, feeRecipientBAta);
  const feeRecipientBalanceBBefore = feeRecipientTokenBBefore.exists ? feeRecipientTokenBBefore.data.amount : 0n;

  // Liquidate the position!
  await sendTransaction(instructions);

  const positionAfter = await fetchPosition(rpc, positionAddress, market.data.marketMaker);
  const tunaPositionAfter = await fetchTunaLpPosition(rpc, tunaPositionAddress);

  assert(positionAfter.data.liquidity == tunaPositionAfter.data.liquidity, "Incorrect liquidity in tuna position");

  const tunaPositionBalanceAAfter = (await fetchToken(rpc, tunaPositionAtaA)).data.amount;
  const tunaPositionBalanceBAfter = (await fetchToken(rpc, tunaPositionAtaB)).data.amount;
  assert(tunaPositionAfter.data.leftoversA == tunaPositionBalanceAAfter, "Incorrect leftovers of token A");
  assert(tunaPositionAfter.data.leftoversB == tunaPositionBalanceBAfter, "Incorrect leftovers of token B");

  const vaultABalanceAfter = (await fetchToken(rpc, vaultAAta)).data.amount;
  const vaultBBalanceAfter = (await fetchToken(rpc, vaultBAta)).data.amount;
  const poolBalanceAAfter = (await fetchToken(rpc, pool.data.tokenVaultA)).data.amount;
  const poolBalanceBAfter = (await fetchToken(rpc, pool.data.tokenVaultB)).data.amount;
  const feeRecipientTokenAAfter = await fetchMaybeToken(rpc, feeRecipientAAta);
  const feeRecipientBalanceAAfter = feeRecipientTokenAAfter.exists ? feeRecipientTokenAAfter.data.amount : 0n;
  const feeRecipientTokenBAfter = await fetchMaybeToken(rpc, feeRecipientBAta);
  const feeRecipientBalanceBAfter = feeRecipientTokenBAfter.exists ? feeRecipientTokenBAfter.data.amount : 0n;

  const vaultAAfter = await fetchVault(rpc, vaultAAddress);
  const vaultBAfter = await fetchVault(rpc, vaultBAddress);

  const marketAfter = await fetchMarket(rpc, marketAddress);
  expect(marketAfter.data.badDebtA - market.data.badDebtA).toEqual(
    vaultAAfter.data.unpaidDebtShares - vaultA.data.unpaidDebtShares,
  );
  expect(marketAfter.data.badDebtB - market.data.badDebtB).toEqual(
    vaultBAfter.data.unpaidDebtShares - vaultB.data.unpaidDebtShares,
  );

  return {
    poolBalanceDeltaA: poolBalanceAAfter - poolBalanceABefore,
    poolBalanceDeltaB: poolBalanceBAfter - poolBalanceBBefore,
    vaultBalanceDeltaA: vaultABalanceAfter - vaultABalanceBefore,
    vaultBalanceDeltaB: vaultBBalanceAfter - vaultBBalanceBefore,
    badDebtDeltaA: vaultAAfter.data.unpaidDebtShares - vaultA.data.unpaidDebtShares,
    badDebtDeltaB: vaultBAfter.data.unpaidDebtShares - vaultB.data.unpaidDebtShares,
    feeRecipientBalanceDeltaA: feeRecipientBalanceAAfter - feeRecipientBalanceABefore,
    feeRecipientBalanceDeltaB: feeRecipientBalanceBAfter - feeRecipientBalanceBBefore,
    tunaPositionState: tunaPositionAfter.data.state,
  };
}
