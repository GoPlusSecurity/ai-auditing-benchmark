# @defituna/client

## 3.7.3

### Patch Changes

- 38b074d: Updated FusionAmm to 1.1.5
- Updated dependencies [38b074d]
  - @crypticdot/defituna-core@3.7.3

## 3.7.2

### Patch Changes

- 54692ec: Updated FusionAmm to 1.1.4
- Updated dependencies [54692ec]
  - @crypticdot/defituna-core@3.7.2

## 3.7.1

### Patch Changes

- b6850c7: Repay debt fix for permissionless markets
  - @crypticdot/defituna-core@3.7.1

## 3.7.0

### Minor Changes

- 76f40c5: Support for FusionAmm 1.1

### Patch Changes

- Updated dependencies [76f40c5]
  - @crypticdot/defituna-core@3.7.0

## 3.6.26

### Patch Changes

- b49a559: Updated market account filters
  - @crypticdot/defituna-core@3.6.26

## 3.6.25

### Patch Changes

- 7f13a96: Improved market filters
  - @crypticdot/defituna-core@3.6.25

## 3.6.24

### Patch Changes

- ee9fd8a: Fixed market closing instruction builder
  - @crypticdot/defituna-core@3.6.24

## 3.6.23

### Patch Changes

- 7fb5b22: Market closing
  - @crypticdot/defituna-core@3.6.23

## 3.6.22

### Patch Changes

- bed52f7: Added positions counter for market
  - @crypticdot/defituna-core@3.6.22

## 3.6.21

### Patch Changes

- d8a798f: Security related fixes
  - @crypticdot/defituna-core@3.6.21

## 3.6.20

### Patch Changes

- 31f70dc: Pumpfun Amm support for jupiter swap
  - @crypticdot/defituna-core@3.6.20

## 3.6.19

### Patch Changes

- 96fd8fd: Removed leverage from get_decrease_spot_position_quote
  - @crypticdot/defituna-core@3.6.19

## 3.6.18

### Patch Changes

- acd6833: Optimized jupiter quoting
  - @crypticdot/defituna-core@3.6.18

## 3.6.17

### Patch Changes

- 439d1ab: Updated spot quote functions
  - @crypticdot/defituna-core@3.6.17

## 3.6.16

### Patch Changes

- 870ab89: Adjusted price_impact calculation in quote functions
  - @crypticdot/defituna-core@3.6.16

## 3.6.15

### Patch Changes

- @crypticdot/defituna-core@3.6.15

## 3.6.14

### Patch Changes

- fca0b63: Optimized building of tuna instructions
  - @crypticdot/defituna-core@3.6.14

## 3.6.13

### Patch Changes

- 50dd9c8: Added referral account
  - @crypticdot/defituna-core@3.6.13

## 3.6.12

### Patch Changes

- 9a51033: Added open_and_increase_tuna_spot_position_jupiter ix, updated spot position increase/decrease quote functions
- Updated dependencies [9a51033]
  - @crypticdot/defituna-core@3.6.12

## 3.6.11

### Patch Changes

- ba60e8d: Removed lock instruction and added the ability to lock via position flags
  - @crypticdot/defituna-core@3.6.11

## 3.6.10

### Patch Changes

- 8b2c05a: Closing of intermediate token accounts for jupiter swaps
  - @crypticdot/defituna-core@3.6.10

## 3.6.9

### Patch Changes

- 72474d9: Updated jupiter instructions
  - @crypticdot/defituna-core@3.6.9

## 3.6.8

### Patch Changes

- 71eb5aa: Added liquidation of Orca positions via Jupiter
  - @crypticdot/defituna-core@3.6.8

## 3.6.7

### Patch Changes

- f52373a: Updated jupiter lp liquidation instruction
  - @crypticdot/defituna-core@3.6.7

## 3.6.6

### Patch Changes

- 3994033: Added getAddressesForFusionMarketLookupTable
  - @crypticdot/defituna-core@3.6.6

## 3.6.5

### Patch Changes

- d184fc9: Updated market LUT addresses list
  - @crypticdot/defituna-core@3.6.5

## 3.6.4

### Patch Changes

- fcd063c: Updated jupiter instructions
  - @crypticdot/defituna-core@3.6.4

## 3.6.3

### Patch Changes

- 1354c16: Ability to pass jupiter program authority to instructions
  - @crypticdot/defituna-core@3.6.3

## 3.6.2

### Patch Changes

- 6b3b516: Updated liquidation instructions
  - @crypticdot/defituna-core@3.6.2

## 3.6.1

### Patch Changes

- 5246f23: LP positions liquidation via jupiter and support for position locking
  - @crypticdot/defituna-core@3.6.1

## 3.6.0

### Minor Changes

- 810637d: Permissionless markets

### Patch Changes

- Updated dependencies [810637d]
  - @crypticdot/defituna-core@3.6.0

## 3.5.13

### Patch Changes

- 43accb6: Permissionless markets
- Updated dependencies [43accb6]
  - @crypticdot/defituna-core@3.5.13

## 3.5.12

### Patch Changes

- 574caaa: Fixed Market account structure
- Updated dependencies [574caaa]
  - @crypticdot/defituna-core@3.5.12

## 3.5.11

### Patch Changes

- 2194ec2: Added reset_market_bad_debt instruction
  - @crypticdot/defituna-core@3.5.11

## 3.5.10

### Patch Changes

- @crypticdot/defituna-core@3.5.10

## 3.5.9

### Patch Changes

- @crypticdot/defituna-core@3.5.9

## 3.5.8

### Patch Changes

- 5914ca4: Added Tuna Oracle
  - @crypticdot/defituna-core@3.5.8

## 3.5.7

### Patch Changes

- @crypticdot/defituna-core@3.5.7

## 3.5.6

### Patch Changes

- 47f2e06: Fixed LP positions opening with provided ephemeral keys
  - @crypticdot/defituna-core@3.5.6

## 3.5.5

### Patch Changes

- 0a3ac17: Updated getOpenTunaLpPositionFusionInstructionWithEphemeralSigner
  - @crypticdot/defituna-core@3.5.5

## 3.5.4

### Patch Changes

- 6183b93: Added multisig support for LP positions
- Updated dependencies [6183b93]
  - @crypticdot/defituna-core@3.5.4

## 3.5.3

### Patch Changes

- @crypticdot/defituna-core@3.5.3

## 3.5.2

### Patch Changes

- @crypticdot/defituna-core@3.5.2

## 3.5.1

### Patch Changes

- Updated dependencies [7931cec]
  - @crypticdot/defituna-core@3.5.1

## 3.5.0

### Minor Changes

- 286065b: Updated tuna program error codes, changed SOL wrapping strategy, simplified amount slippage

### Patch Changes

- Updated dependencies [286065b]
  - @crypticdot/defituna-core@3.5.0

## 3.4.8

### Patch Changes

- @crypticdot/defituna-core@3.4.8

## 3.4.7

### Patch Changes

- @crypticdot/defituna-core@3.4.7

## 3.4.6

### Patch Changes

- @crypticdot/defituna-core@3.4.6

## 3.4.5

### Patch Changes

- @crypticdot/defituna-core@3.4.5

## 3.4.4

### Patch Changes

- @crypticdot/defituna-core@3.4.4

## 3.4.3

### Patch Changes

- @crypticdot/defituna-core@3.4.3

## 3.4.2

### Patch Changes

- @crypticdot/defituna-core@3.4.2

## 3.4.1

### Patch Changes

- 28de88e: Updated fusionamm version
  - @crypticdot/defituna-core@3.4.1

## 3.4.0

### Minor Changes

- ac53634: Isolated lending vaults and permissionless markets

### Patch Changes

- Updated dependencies [ac53634]
  - @crypticdot/defituna-core@3.4.0

## 3.3.6

### Patch Changes

- c871aab: Ability to set arbitrary lending vaults when creating a market
  - @crypticdot/defituna-core@3.3.6

## 3.3.5

### Patch Changes

- 22b4b20: Improved getDecreaseSpotPositionQuote
- Updated dependencies [22b4b20]
  - @crypticdot/defituna-core@3.3.5

## 3.3.4

### Patch Changes

- f68ed6a: bugfix: impossible to open a spot position with SOL as collateral
  - @crypticdot/defituna-core@3.3.4

## 3.3.3

### Patch Changes

- da4f791: Fixed liquidation instruction issues
  - @crypticdot/defituna-core@3.3.3

## 3.3.2

### Patch Changes

- 7ad7213: Fixed errors in modifyTunaSpotPosition instruction builder
  - @crypticdot/defituna-core@3.3.2

## 3.3.1

### Patch Changes

- 48b5790: Got rid of position reversing
- Updated dependencies [48b5790]
  - @crypticdot/defituna-core@3.3.1

## 3.3.0

### Minor Changes

- b838600: Replaced increase/decrease spot instructions with the single modify ix

### Patch Changes

- Updated dependencies [b838600]
  - @crypticdot/defituna-core@3.3.0

## 3.2.7

### Patch Changes

- 0103e9b: Replaced open_tuna_spot_position_orca/fusion instructions with the single one
- Updated dependencies [0103e9b]
  - @crypticdot/defituna-core@3.2.7

## 3.2.6

### Patch Changes

- b755617: Spot position increase/decrease via jupiter
- Updated dependencies [b755617]
  - @crypticdot/defituna-core@3.2.6

## 3.2.5

### Patch Changes

- @crypticdot/defituna-core@3.2.5

## 3.2.4

### Patch Changes

- @crypticdot/defituna-core@3.2.4

## 3.2.3

### Patch Changes

- 1bb2f63: Updated repayTunaLpPositionDebtInstructions
  - @crypticdot/defituna-core@3.2.3

## 3.2.2

### Patch Changes

- @crypticdot/defituna-core@3.2.2

## 3.2.1

### Patch Changes

- @crypticdot/defituna-core@3.2.1

## 3.2.0

### Minor Changes

- e917743: Added defituna core library and moved some math to it

### Patch Changes

- Updated dependencies [e917743]
  - @crypticdot/defituna-core@3.2.0

## 3.1.19

### Patch Changes

- 7db3a70: Updated spot instructions: added min/max swap amounts, removed flags and limit order prices at position opening

## 3.1.18

### Patch Changes

- 84df975: Fixed getTradableAmount() function

## 3.1.17

### Patch Changes

- 63a9e0f: Bugfix in getTradableAmount function

## 3.1.16

### Patch Changes

- 3812220: Added getTradableAmount function

## 3.1.15

### Patch Changes

- 712a9d5: Fixed bug in getDecreaseSpotPositionQuote

## 3.1.14

### Patch Changes

- 56ff7d8: Updated getPositionSizeByCollateralAndLeverage arguments

## 3.1.13

### Patch Changes

- f33d5a3: Improved getDecreaseSpotPositionQuote math

## 3.1.12

### Patch Changes

- b209391: Improved getIncreaseSpotPositionQuote math, added getPositionSizeByCollateralAndLeverage

## 3.1.11

### Patch Changes

- a8cd97a: Updated fusionamm sdk

## 3.1.10

### Patch Changes

- 91616d2: Fixed a bug in getDecreaseSpotPositionQuote function for positions without leverage

## 3.1.9

### Patch Changes

- 2cbe483: Fixed bugs in getDecreaseSpotPositionQuote function

## 3.1.8

### Patch Changes

- 9b313c0: Fixed bugs in getDecreaseSpotPositionQuote function

## 3.1.7

### Patch Changes

- 13b09fb: Fixed bugs in getIncrease(Decrease)SpotPositionQuote functions

## 3.1.6

### Patch Changes

- 77320a2: Added liquidation price calculation

## 3.1.5

### Patch Changes

- ae2626b: Fixed creation of the user's token account on position close

## 3.1.4

### Patch Changes

- 354588a: Added getDecreaseSpotPositionQuote

## 3.1.3

### Patch Changes

- d6c65bf: Added spot position limit, added getIncreaseSpotPositionQuote()

## 3.1.2

### Patch Changes

- ce3cc97: Fixed incorrect TunaSpotPosition account length

## 3.1.1

### Patch Changes

- b1555dc: Transfer tokens directly to the spot position owner on liquidation/closing by an order

## 3.1.0

### Minor Changes

- 7e965d3: Single spot position per pool

## 3.0.4

### Patch Changes

- 3f4fdc0: Added pyth price feed account derivation

## 3.0.3

### Patch Changes

- 4cb4302: Added reset_tuna_spot_position ix

## 3.0.2

### Patch Changes

- 2aaee6f: Renamed t/p and s/l constants

## 3.0.1

### Patch Changes

- 0741685: Renamed take profit/stop loss to lower/upper orders

## 3.0.0

### Major Changes

- 5f51b19: DefiTuna 3.0

## 2.0.17

### Patch Changes

- fdf18d1: bugfix: incorrect protocol fee calculation in getIncreaseLpPositionQuote

## 2.0.16

### Patch Changes

- 961ae7e: bugfix: incorrect liquidation instruction builder

## 2.0.15

### Patch Changes

- 207d79e: Changed liquidation fees recipient

## 2.0.14

### Patch Changes

- adce08b: Accounts initialization cost calculation for the position opening and rebalancing

## 2.0.13

### Patch Changes

- 158f45e: Updated the fee model of auto-rebalanceable positions and removed raydium related code

## 2.0.12

### Patch Changes

- 1da0fca: Updated FusionAMM packages

## 2.0.11

### Patch Changes

- a5eddd1: Tuna program 2.0.7 (updated Whirlpool program to 0.5.0)

## 2.0.10

### Patch Changes

- 5c5924c: Bugfix in sol wrapping code

## 2.0.9

### Patch Changes

- 5571191: Updated fusionamm and orca dependencies

## 2.0.8

### Patch Changes

- de2c913: Change the order of entries in AccountsType structure

## 2.0.7

### Patch Changes

- bab18f4: - Added rust instruction builders for fusion pools
  - Added tuna position re-balance instruction

## 2.0.6

### Patch Changes

- 5b3552e: Fixed liquidity getIncreaseLpPositionQuote overflow issue (updated fusionamm packages)

## 2.0.5

### Patch Changes

- 5857597: Bugfix: Incorrect results returned by getIncreaseLpPositionQuote

## 2.0.4

### Patch Changes

- 421e559: Chnaged the scope of packages to @crypticdot

## 2.0.3

### Patch Changes

- 3c8aab0: Bugfix: openAndIncreaseTunaLpPositionFusionInstructions/openAndIncreaseTunaLpPositionOrcaInstructions incorrect amount slippage calculation

## 2.0.2

### Patch Changes

- 3bbd108: Bugfix: getIncreaseLpPositionQuote returns incorrect results for auto position ratio

## 2.0.1

### Patch Changes

- 64a4415: Changed input arguments of addLiquidity and openAndIncreaseTunaLpPosition instructions.
  Added getIncreaseLpPositionQuote function.

## 2.0.0

### Major Changes

- 224d33a: Added support for FusionAMM pools

## 1.0.30

### Patch Changes

- 11fe02d: Token accounts creation in repayDebt tx builder

## 1.0.29

### Patch Changes

- 99212bb: Added repayDebt instruction builder

## 1.0.28

### Patch Changes

- 287077d: Updated whirlpools packages to 2.0.0

## 1.0.27

### Patch Changes

- 388ee7d: Added closeActiveTunaLpPositionOrca transaction helper

## 1.0.26

### Patch Changes

- 4e5f35a: Tuna program 1.0.67

## 1.0.25

### Patch Changes

- 6c7ad44: Tuna program update to 1.0.66

## 1.0.24

### Patch Changes

- 7046a0b: Tuna program 1.0.65

## 1.0.23

### Patch Changes

- 78dc7dc: Added instruction builders to rust client

## 1.0.22

### Patch Changes

- 304b61e: Updated ts examples

## 1.0.21

### Patch Changes

- 445a4bd: Tuna program 1.0.64

## 1.0.20

### Patch Changes

- 4505283: Improved the transaction builder

## 1.0.19

### Patch Changes

- d3a8972: Renamed createLendingPosition to openLendingPosition; Added openLendingPositionAndDeposit instruction helper

## 1.0.18

### Patch Changes

- e8b6496: Added setLimitOrders instruction helper

## 1.0.17

### Patch Changes

- edfc1b8: Bugfix in openAndIncreaseTunaLpPosition instruction

## 1.0.16

### Patch Changes

- f86e213: Fixed the broken build
- 089c5a5: Added openAndIncreaseTunaLpPosition instruction. Updated tuna to 1.0.63.

## 1.0.15

### Patch Changes

- aae6898: Changed increaseTunaLpPositionOrca instruction helper

## 1.0.14

### Patch Changes

- 5094087: Fixed collectFeesOrca instruction helper

## 1.0.13

### Patch Changes

- 29b682c: Added WSOL mint support in instruction helpers

## 1.0.12

### Patch Changes

- a04a33a: Improved instruction helpers

## 1.0.11

### Patch Changes

- 6f3611f: Added simplified tuna instructions

## 1.0.10

### Patch Changes

- 03c74d1: Added lending position filters

## 1.0.9

### Patch Changes

- 73ad25a: Moved codama script inside packages

## 1.0.8

### Patch Changes

- f766847: Added tuna position fetch filters

## 1.0.7

### Patch Changes

- 0e0e455: Updated tuna constants

## 1.0.6

### Patch Changes

- 293db82: Updated codama version

## 1.0.5

### Patch Changes

- f1be18d: Removed Orca accounts and types

## 1.0.4

### Patch Changes

- f4fd7fc: Updated IDL to 1.0.58

## 1.0.3

### Patch Changes

- 81664a2: Updated tuna program to 1.0.55

## 1.0.2

### Patch Changes

- Remove post-install script

## 1.0.1

### Patch Changes

- 753a1e5: Updated IDL to 1.0.54

## 1.0.0

### Major Changes

- cd10597: Public version
