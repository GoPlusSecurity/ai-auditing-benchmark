# @crypticdot/defituna-rust-examples

## 2.0.7

### Patch Changes

- 7fb5b22: Market closing

## 2.0.6

### Patch Changes

- 187204a: Updated orca crates versions

## 2.0.5

### Patch Changes

- 3ad885c: Updated dependencies in the rust client and fixed rust examples

## 2.0.4

### Patch Changes

- 66926b6: Use of granular solana crates instead of solana-sdk

## 2.0.3

### Patch Changes

- 5571191: Updated fusionamm and orca dependencies

## 2.0.2

### Patch Changes

- bab18f4: - Added rust instruction builders for fusion pools
  - Added tuna position re-balance instruction

## 2.0.1

### Patch Changes

- 421e559: Chnaged the scope of packages to @crypticdot
