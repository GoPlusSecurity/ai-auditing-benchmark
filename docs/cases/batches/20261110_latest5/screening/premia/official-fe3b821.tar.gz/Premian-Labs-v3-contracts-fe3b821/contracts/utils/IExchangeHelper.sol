// SPDX-License-Identifier: LGPL-3.0-or-later
// For terms and conditions regarding commercial use please see https://license.premia.blue
pragma solidity ^0.8.19;

/// @title Premia Exchange Helper
/// @dev deployed standalone and referenced by internal functions
/// @dev do NOT set approval to this contract!
interface IExchangeHelper {
    /// @notice perform arbitrary swap transaction
    /// @param sourceToken source token to pull into this address
    /// @param targetToken target token to buy
    /// @param sourceTokenAmount amount of source token to start the trade
    /// @param callee exchange address to call to execute the trade.
    /// @param allowanceTarget address for which to set allowance for the trade
    /// @param data calldata to execute the trade
    /// @param refundAddress address that un-used source token goes to
    /// @return amountOut quantity of targetToken yielded by swap
    /// @return sourceLeft quantity of sourceToken left and refunded to refundAddress
    function swapWithToken(
        address sourceToken,
        address targetToken,
        uint256 sourceTokenAmount,
        address callee,
        address allowanceTarget,
        bytes calldata data,
        address refundAddress
    ) external returns (uint256 amountOut, uint256 sourceLeft);
}
